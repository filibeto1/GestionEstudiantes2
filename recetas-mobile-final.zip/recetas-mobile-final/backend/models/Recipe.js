// backend/models/Recipe.js
const mongoose = require('mongoose');

const recipeSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
    default: 'Receta sin título' // ✅ VALOR POR DEFECTO
  },
  description: {
    type: String,
    required: true,
    default: 'Descripción no disponible' // ✅ VALOR POR DEFECTO
  },
  ingredients: [{
    name: {
      type: String,
      default: 'Ingrediente sin nombre' // ✅ VALOR POR DEFECTO
    },
    quantity: {
      type: String,
      default: '' // ✅ VALOR POR DEFECTO
    },
    unit: {
      type: String,
      default: '' // ✅ VALOR POR DEFECTO
    }
  }],
  instructions: [{
    step: {
      type: Number,
      required: true
    },
    description: {
      type: String,
      required: true,
      default: 'Instrucción no disponible' // ✅ VALOR POR DEFECTO
    }
  }],
  preparationTime: {
    type: Number, // en minutos
    required: true,
    default: 30 // ✅ VALOR POR DEFECTO
  },
  servings: {
    type: Number,
    required: true,
    default: 1 // ✅ VALOR POR DEFECTO
  },
  difficulty: {
    type: String,
    enum: ['Fácil', 'Medio', 'Difícil'],
    required: true,
    default: 'Medio' // ✅ VALOR POR DEFECTO
  },
  category: {
    type: String,
    enum: ['Desayuno', 'Almuerzo', 'Cena', 'Postre', 'Snack', 'Bebida'],
    required: true,
    default: 'General' // ✅ NECESITAS AGREGAR 'General' AL ENUM O CAMBIARLO
  },
  image: {
    type: String, // URL de la imagen
    default: ''
  },
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  authorName: {
    type: String,
    required: true,
    default: 'Anónimo' // ✅ VALOR POR DEFECTO
  },
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  likesCount: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Recipe', recipeSchema);