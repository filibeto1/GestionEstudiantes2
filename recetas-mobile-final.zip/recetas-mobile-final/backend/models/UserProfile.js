const mongoose = require('mongoose');

const userProfileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  
  // Información Personal
  personalInfo: {
    age: { type: Number, min: 1, max: 120 },
    weight: { type: Number, min: 1, max: 300 },
    height: { type: Number, min: 50, max: 250 },
    gender: {
      type: String,
      enum: ['male', 'female', 'other', 'prefer_not_to_say']
    },
    activityLevel: {
      type: String,
      enum: ['sedentary', 'light', 'moderate', 'active', 'very_active']
    },
    dailyCalorieGoal: { type: Number, min: 500, max: 5000 }
  },
  
  // Salud
  healthInfo: {
    allergies: { type: [String], default: [] },
    dietaryRestrictions: { type: [String], default: [] },
    healthConditions: { type: [String], default: [] },
    healthGoals: { type: [String], default: [] }
  },
  
  // Preferencias
  preferences: {
    favoriteCuisines: { type: [String], default: [] },
    dislikedIngredients: { type: [String], default: [] },
    cookingSkills: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced']
    }
  },
  
  // Metadata
  lastUpdated: { type: Date, default: Date.now },
  bmi: { type: Number }
}, { 
  timestamps: true 
});

// Calcular BMI automáticamente
userProfileSchema.methods.calculateBMI = function() {
  if (this.personalInfo.weight && this.personalInfo.height) {
    const heightInMeters = this.personalInfo.height / 100;
    this.bmi = this.personalInfo.weight / (heightInMeters * heightInMeters);
  }
  return this.bmi;
};

// Middleware para calcular BMI antes de guardar
userProfileSchema.pre('save', function(next) {
  this.calculateBMI();
  this.lastUpdated = new Date();
  next();
});

module.exports = mongoose.model('UserProfile', userProfileSchema);