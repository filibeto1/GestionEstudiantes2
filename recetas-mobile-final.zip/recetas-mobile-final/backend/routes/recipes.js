const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Recipe = require('../models/Recipe');

// Obtener todas las recetas de la comunidad
router.get('/community', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    console.log(`🔍 Buscando recetas - Página: ${page}, Límite: ${limit}`);
    
    const recipes = await Recipe.find()
      .populate('author', 'username')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);
    
    const totalRecipes = await Recipe.countDocuments();
    const totalPages = Math.ceil(totalRecipes / limit);

    const validatedRecipes = recipes.map(recipe => {
      const recipeObj = recipe.toObject();
      return {
        ...recipeObj,
        title: recipeObj.title || 'Receta sin título',
        description: recipeObj.description || 'Descripción no disponible',
        ingredients: recipeObj.ingredients || [],
        instructions: recipeObj.instructions || [],
        category: recipeObj.category || 'General',
        difficulty: recipeObj.difficulty || 'Medio',
        preparationTime: recipeObj.preparationTime || 30,
        servings: recipeObj.servings || 1,
        likesCount: recipeObj.likesCount || 0,
        authorName: recipeObj.authorName || (recipeObj.author && recipeObj.author.username) || 'Anónimo'
      };
    });
    
    console.log(`✅ Enviando ${validatedRecipes.length} recetas de ${totalRecipes} totales`);
    
    res.json({
      success: true,
      recipes: validatedRecipes,
      pagination: {
        currentPage: page,
        totalPages: totalPages,
        totalRecipes: totalRecipes,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      }
    });
  } catch (error) {
    console.error('❌ Error obteniendo recetas:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener recetas'
    });
  }
});

// Obtener recetas del usuario actual
router.get('/my-recipes', auth, async (req, res) => {
  try {
    const recipes = await Recipe.find({ author: req.user._id })
      .sort({ createdAt: -1 });
    
    res.json({
      success: true,
      recipes
    });
  } catch (error) {
    console.error('Error obteniendo recetas del usuario:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener tus recetas'
    });
  }
});

// Crear nueva receta
router.post('/', auth, async (req, res) => {
  try {
    const {
      title,
      description,
      ingredients,
      instructions,
      preparationTime,
      servings,
      difficulty,
      category,
      image
    } = req.body;

    const recipe = new Recipe({
      title,
      description,
      ingredients,
      instructions,
      preparationTime,
      servings,
      difficulty,
      category,
      image: image || '',
      author: req.user._id,
      authorName: req.user.username
    });

    await recipe.save();

    res.status(201).json({
      success: true,
      message: 'Receta creada exitosamente',
      recipe
    });
  } catch (error) {
    console.error('Error creando receta:', error);
    res.status(500).json({
      success: false,
      message: 'Error al crear receta'
    });
  }
});

// Obtener una receta específica
router.get('/:id', async (req, res) => {
  try {
    console.log('🔍 Buscando receta en BD con ID:', req.params.id);
    
    const recipe = await Recipe.findById(req.params.id)
      .populate('author', 'username');
    
    if (!recipe) {
      console.log('❌ Receta NO encontrada en BD');
      return res.status(404).json({
        success: false,
        message: 'Receta no encontrada'
      });
    }

    console.log('✅ Receta encontrada en BD:', recipe.title);
    console.log('📊 Datos de la receta:', {
      titulo: recipe.title,
      ingredientes: recipe.ingredients.length,
      instrucciones: recipe.instructions.length,
      autor: recipe.authorName
    });

    res.json({
      success: true,
      recipe
    });
  } catch (error) {
    console.error('❌ Error obteniendo receta:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener receta'
    });
  }
});

// Like/Unlike a receta
router.post('/:id/like', auth, async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    
    if (!recipe) {
      return res.status(404).json({
        success: false,
        message: 'Receta no encontrada'
      });
    }

    const hasLiked = recipe.likes.includes(req.user._id);
    
    if (hasLiked) {
      recipe.likes = recipe.likes.filter(like => 
        like.toString() !== req.user._id.toString()
      );
      recipe.likesCount = Math.max(0, recipe.likesCount - 1);
    } else {
      recipe.likes.push(req.user._id);
      recipe.likesCount += 1;
    }

    await recipe.save();

    res.json({
      success: true,
      likesCount: recipe.likesCount,
      hasLiked: !hasLiked
    });
  } catch (error) {
    console.error('Error en like:', error);
    res.status(500).json({
      success: false,
      message: 'Error al procesar like'
    });
  }
});

// Eliminar receta
router.delete('/:id', auth, async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    
    if (!recipe) {
      return res.status(404).json({
        success: false,
        message: 'Receta no encontrada'
      });
    }

    if (recipe.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para eliminar esta receta'
      });
    }

    await Recipe.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: 'Receta eliminada exitosamente'
    });
  } catch (error) {
    console.error('Error eliminando receta:', error);
    res.status(500).json({
      success: false,
      message: 'Error al eliminar receta'
    });
  }
});

module.exports = router;