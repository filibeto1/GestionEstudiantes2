const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const UserProfile = require('../models/UserProfile');

// Obtener perfil completo del usuario
router.get('/', auth, async (req, res) => {
  try {
    console.log('📋 Obteniendo perfil completo para:', req.user._id);
    
    let userProfile = await UserProfile.findOne({ userId: req.user._id });
    
    if (!userProfile) {
      // Crear perfil vacío si no existe
      userProfile = new UserProfile({
        userId: req.user._id,
        personalInfo: {},
        healthInfo: {},
        preferences: {}
      });
      await userProfile.save();
      console.log('✅ Nuevo perfil creado automáticamente');
    }

    res.json({
      success: true,
      profile: userProfile
    });
  } catch (error) {
    console.error('❌ Error obteniendo perfil:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener perfil'
    });
  }
});

// Actualizar perfil completo
router.put('/', auth, async (req, res) => {
  try {
    const { personalInfo, healthInfo, preferences } = req.body;

    console.log('🔄 Actualizando perfil completo:', req.user._id);
    console.log('📦 Datos recibidos:', JSON.stringify(req.body, null, 2));

    let userProfile = await UserProfile.findOne({ userId: req.user._id });
    
    if (!userProfile) {
      // Crear nuevo perfil si no existe
      userProfile = new UserProfile({
        userId: req.user._id,
        personalInfo: personalInfo || {},
        healthInfo: healthInfo || {},
        preferences: preferences || {}
      });
    } else {
      // Actualizar perfil existente
      if (personalInfo) userProfile.personalInfo = { ...userProfile.personalInfo, ...personalInfo };
      if (healthInfo) userProfile.healthInfo = { ...userProfile.healthInfo, ...healthInfo };
      if (preferences) userProfile.preferences = { ...userProfile.preferences, ...preferences };
    }

    await userProfile.save();

    console.log('✅ Perfil guardado en colección separada');
    console.log('💾 Perfil guardado:', JSON.stringify(userProfile, null, 2));

    res.json({
      success: true,
      message: 'Perfil actualizado exitosamente',
      profile: userProfile
    });
  } catch (error) {
    console.error('❌ Error actualizando perfil:', error);
    res.status(500).json({
      success: false,
      message: 'Error al actualizar perfil',
      error: error.message
    });
  }
});

// Actualizar información personal
router.patch('/personal', auth, async (req, res) => {
  try {
    const personalInfo = req.body;

    console.log('🎯 Actualizando info personal:', req.user._id);
    console.log('📊 Datos personales:', personalInfo);

    let userProfile = await UserProfile.findOne({ userId: req.user._id });
    
    if (!userProfile) {
      userProfile = new UserProfile({
        userId: req.user._id,
        personalInfo: personalInfo,
        healthInfo: {},
        preferences: {}
      });
    } else {
      userProfile.personalInfo = { ...userProfile.personalInfo, ...personalInfo };
    }

    await userProfile.save();

    res.json({
      success: true,
      message: 'Información personal actualizada',
      profile: userProfile
    });
  } catch (error) {
    console.error('❌ Error actualizando info personal:', error);
    res.status(500).json({
      success: false,
      message: 'Error al actualizar información personal'
    });
  }
});

// Actualizar información de salud
router.patch('/health', auth, async (req, res) => {
  try {
    const healthInfo = req.body;

    console.log('🏥 Actualizando info salud:', req.user._id);
    console.log('📊 Datos salud:', healthInfo);

    let userProfile = await UserProfile.findOne({ userId: req.user._id });
    
    if (!userProfile) {
      userProfile = new UserProfile({
        userId: req.user._id,
        personalInfo: {},
        healthInfo: healthInfo,
        preferences: {}
      });
    } else {
      userProfile.healthInfo = { ...userProfile.healthInfo, ...healthInfo };
    }

    await userProfile.save();

    res.json({
      success: true,
      message: 'Información de salud actualizada',
      profile: userProfile
    });
  } catch (error) {
    console.error('❌ Error actualizando info salud:', error);
    res.status(500).json({
      success: false,
      message: 'Error al actualizar información de salud'
    });
  }
});

// Calcular IMC
router.get('/bmi', auth, async (req, res) => {
  try {
    const userProfile = await UserProfile.findOne({ userId: req.user._id });
    
    if (!userProfile || !userProfile.personalInfo.weight || !userProfile.personalInfo.height) {
      return res.status(400).json({
        success: false,
        message: 'Se requiere peso y altura para calcular IMC'
      });
    }

    const bmi = userProfile.calculateBMI();
    
    let category = '';
    if (bmi < 18.5) category = 'Bajo peso';
    else if (bmi < 25) category = 'Peso normal';
    else if (bmi < 30) category = 'Sobrepeso';
    else category = 'Obesidad';

    res.json({
      success: true,
      bmi: bmi.toFixed(1),
      category,
      weight: userProfile.personalInfo.weight,
      height: userProfile.personalInfo.height
    });
  } catch (error) {
    console.error('❌ Error calculando IMC:', error);
    res.status(500).json({
      success: false,
      message: 'Error al calcular IMC'
    });
  }
});

// Obtener estadísticas del perfil
router.get('/stats', auth, async (req, res) => {
  try {
    const userProfile = await UserProfile.findOne({ userId: req.user._id });
    
    if (!userProfile) {
      return res.json({
        success: true,
        stats: {
          hasPersonalInfo: false,
          hasHealthInfo: false,
          profileCompletion: 0
        }
      });
    }

    const stats = {
      hasPersonalInfo: !!(userProfile.personalInfo.age || userProfile.personalInfo.weight || userProfile.personalInfo.height),
      hasHealthInfo: !!(userProfile.healthInfo.allergies.length > 0 || userProfile.healthInfo.healthGoals.length > 0),
      profileCompletion: calculateProfileCompletion(userProfile),
      lastUpdated: userProfile.lastUpdated
    };

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('❌ Error obteniendo estadísticas:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener estadísticas'
    });
  }
});

function calculateProfileCompletion(profile) {
  let completion = 0;
  const totalFields = 8; // Campos importantes
  
  if (profile.personalInfo.age) completion++;
  if (profile.personalInfo.weight) completion++;
  if (profile.personalInfo.height) completion++;
  if (profile.personalInfo.gender) completion++;
  if (profile.personalInfo.activityLevel) completion++;
  if (profile.healthInfo.allergies.length > 0) completion++;
  if (profile.healthInfo.healthConditions.length > 0) completion++;
  if (profile.healthInfo.healthGoals.length > 0) completion++;

  return Math.round((completion / totalFields) * 100);
}

module.exports = router;