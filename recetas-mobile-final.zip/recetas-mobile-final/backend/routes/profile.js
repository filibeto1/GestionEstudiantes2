// backend/routes/profile.js - VERSIÓN SIMPLIFICADA
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');

// Obtener perfil completo del usuario
router.get('/', auth, async (req, res) => {
  try {
    console.log('📋 Obteniendo perfil completo para:', req.user._id);
    
    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Asegurarse de que el perfil tenga la estructura correcta
    if (!user.profile) {
      user.profile = {
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      };
      await user.save();
    }

    console.log('✅ Perfil cargado exitosamente');
    
    res.json({
      success: true,
      profile: user.profile
    });
  } catch (error) {
    console.error('❌ Error obteniendo perfil:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener perfil'
    });
  }
});

// Actualizar perfil completo
router.put('/', auth, async (req, res) => {
  try {
    const { profile } = req.body;

    console.log('🔄 Actualizando perfil completo:', req.user._id);
    console.log('📦 Datos recibidos:', JSON.stringify(profile, null, 2));

    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Actualizar perfil manteniendo la estructura
    user.profile = {
      personalInfo: profile.personalInfo || user.profile?.personalInfo || {},
      healthInfo: {
        allergies: profile.healthInfo?.allergies || user.profile?.healthInfo?.allergies || [],
        dietaryRestrictions: profile.healthInfo?.dietaryRestrictions || user.profile?.healthInfo?.dietaryRestrictions || [],
        healthConditions: profile.healthInfo?.healthConditions || user.profile?.healthInfo?.healthConditions || [],
        healthGoals: profile.healthInfo?.healthGoals || user.profile?.healthInfo?.healthGoals || []
      },
      preferences: profile.preferences || user.profile?.preferences || {
        favoriteCuisines: [],
        dislikedIngredients: [],
        cookingSkills: 'beginner'
      }
    };

    await user.save();

    console.log('✅ Perfil actualizado exitosamente');
    console.log('💾 Perfil guardado:', JSON.stringify(user.profile, null, 2));

    res.json({
      success: true,
      message: 'Perfil actualizado exitosamente',
      profile: user.profile
    });
  } catch (error) {
    console.error('❌ Error actualizando perfil:', error);
    res.status(500).json({
      success: false,
      message: 'Error al actualizar perfil',
      error: error.message
    });
  }
});

// Actualizar información personal
router.patch('/personal', auth, async (req, res) => {
  try {
    const personalInfo = req.body;

    console.log('🎯 Actualizando info personal:', req.user._id);
    console.log('📊 Datos personales:', personalInfo);

    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Inicializar perfil si no existe
    if (!user.profile) {
      user.profile = {
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      };
    }

    // Actualizar información personal
    user.profile.personalInfo = {
      ...user.profile.personalInfo,
      ...personalInfo
    };

    await user.save();

    console.log('✅ Información personal actualizada');

    res.json({
      success: true,
      message: 'Información personal actualizada',
      profile: user.profile
    });
  } catch (error) {
    console.error('❌ Error actualizando info personal:', error);
    res.status(500).json({
      success: false,
      message: 'Error al actualizar información personal'
    });
  }
});

// Actualizar información de salud
router.patch('/health', auth, async (req, res) => {
  try {
    const healthInfo = req.body;

    console.log('🏥 Actualizando info salud:', req.user._id);
    console.log('📊 Datos salud:', healthInfo);

    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Inicializar perfil si no existe
    if (!user.profile) {
      user.profile = {
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      };
    }

    // Actualizar información de salud
    user.profile.healthInfo = {
      allergies: healthInfo.allergies || user.profile.healthInfo.allergies || [],
      dietaryRestrictions: healthInfo.dietaryRestrictions || user.profile.healthInfo.dietaryRestrictions || [],
      healthConditions: healthInfo.healthConditions || user.profile.healthInfo.healthConditions || [],
      healthGoals: healthInfo.healthGoals || user.profile.healthInfo.healthGoals || []
    };

    await user.save();

    console.log('✅ Información de salud actualizada');

    res.json({
      success: true,
      message: 'Información de salud actualizada',
      profile: user.profile
    });
  } catch (error) {
    console.error('❌ Error actualizando info salud:', error);
    res.status(500).json({
      success: false,
      message: 'Error al actualizar información de salud'
    });
  }
});

module.exports = router;