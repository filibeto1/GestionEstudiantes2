import axios from 'axios';
import { Recipe, Ingredient, Instruction } from '../types';
import { translationService } from './translation';

const API_BASE_URL = 'https://www.themealdb.com/api/json/v1/1';

// Traductor mejorado de categorías
const translateCategory = (category: string): string => {
  const translations: { [key: string]: string } = {
    'Beef': 'Carne de Res',
    'Chicken': 'Pollo',
    'Dessert': 'Postre',
    'Lamb': 'Cordero',
    'Miscellaneous': 'Variado',
    'Pasta': 'Pasta',
    'Pork': 'Cerdo',
    'Seafood': 'Mariscos',
    'Side': 'Acompañamiento',
    'Starter': 'Entrada',
    'Vegan': 'Vegano',
    'Vegetarian': 'Vegetariano',
    'Breakfast': 'Desayuno',
    'Goat': 'Cabra',
    '': 'General'
  };
  return translations[category] || category;
};

// Traductor de ingredientes comunes para TheMealDB
const traducirIngrediente = (ingrediente: string): string => {
  const traducciones: { [key: string]: string } = {
    'salt': 'sal',
    'pepper': 'pimienta',
    'sugar': 'azúcar',
    'flour': 'harina',
    'butter': 'mantequilla',
    'oil': 'aceite',
    'garlic': 'ajo',
    'onion': 'cebolla',
    'tomato': 'tomate',
    'egg': 'huevo',
    'milk': 'leche',
    'water': 'agua',
    'rice': 'arroz',
    'chicken': 'pollo',
    'beef': 'carne de res',
    'pork': 'cerdo',
    'fish': 'pescado',
    'cheese': 'queso',
    'bread': 'pan',
    'lemon': 'limón',
    'lime': 'lima',
    'carrot': 'zanahoria',
    'potato': 'papa',
    'bell pepper': 'pimiento',
    'cilantro': 'cilantro',
    'parsley': 'perejil',
    'basil': 'albahaca',
    'oregano': 'orégano',
    'vinegar': 'vinagre',
    'soy sauce': 'salsa de soya',
    'honey': 'miel',
    'yogurt': 'yogur',
    'cream': 'crema'
  };

  const ingredienteLower = ingrediente.toLowerCase().trim();
  return traducciones[ingredienteLower] || ingrediente;
};

// ✅ Mapear datos de TheMealDB a nuestro formato de manera SEGURA
const mapMealToRecipe = (meal: any): Recipe | null => {
  try {
    // ✅ VERIFICACIÓN SEGURA DE LA RECETA
    if (!meal) {
      console.error('❌ Meal es undefined o null en mapMealToRecipe');
      return null;
    }

    // ✅ VERIFICAR TÍTULO - CORRECCIÓN DEL ERROR
    const title = meal.strMeal || 'Receta sin nombre';
    if (!title || title === 'undefined') {
      console.error('❌ Título inválido en receta:', meal);
      return null;
    }

    const category = meal.strCategory || 'General';
    const description = `Deliciosa receta de ${title} - ${translateCategory(category)}`;
    
    const ingredients: Ingredient[] = [];
    
    // ✅ EXTRAER INGREDIENTES DE MANERA SEGURA
    for (let i = 1; i <= 20; i++) {
      const ingredient = meal[`strIngredient${i}`];
      const measure = meal[`strMeasure${i}`];
      
      if (ingredient && typeof ingredient === 'string' && ingredient.trim()) {
        ingredients.push({
          name: traducirIngrediente(ingredient),
          quantity: measure && typeof measure === 'string' ? measure.trim() : '',
          unit: ''
        });
      }
    }

    // ✅ CONVERTIR INSTRUCCIONES DE MANERA SEGURA
    const instructions: Instruction[] = [];
    if (meal.strInstructions && typeof meal.strInstructions === 'string') {
      const steps = meal.strInstructions
        .split('\r\n')
        .filter((step: string) => step && step.trim())
        .map((step: string, index: number) => ({
          step: index + 1,
          description: step.trim()
        }));
      
      instructions.push(...steps);
    }

    // ✅ SI NO HAY INSTRUCCIONES, AGREGAR UNA POR DEFECTO
    if (instructions.length === 0) {
      instructions.push({
        step: 1,
        description: `Preparar ${title} según las instrucciones tradicionales.`
      });
    }

    // ✅ CREAR RECETA CON VALORES POR DEFECTO SEGUROS
    const recipe: Recipe = {
      _id: meal.idMeal || `meal-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title: title,
      description: description,
      ingredients: ingredients,
      instructions: instructions,
      preparationTime: 30, // Valor por defecto
      servings: 4, // Valor por defecto
      difficulty: 'Medio' as const,
      category: translateCategory(category) as any,
      image: meal.strMealThumb || 'https://via.placeholder.com/400x300?text=Receta+Sin+Imagen',
      author: 'themealdb',
      authorName: 'TheMealDB',
      likes: [],
      likesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    console.log(`✅ Receta mapeada: "${title}" con ${ingredients.length} ingredientes y ${instructions.length} instrucciones`);
    return recipe;

  } catch (error) {
    console.error('❌ Error crítico en mapMealToRecipe:', error);
    return null;
  }
};

// ✅ FUNCIÓN SEGURA PARA TRADUCIR RECETA COMPLETA
const translateMealDbRecipe = async (recipe: Recipe | null): Promise<Recipe | null> => {
  if (!recipe) {
    console.log('❌ No se puede traducir - receta es null');
    return null;
  }

  try {
    console.log(`🍳 Aplicando traducción COMPLETA a: "${recipe.title}"`);
    
    // Usar el servicio de traducción corregido
    const translatedRecipe = await translationService.translateRecipe(recipe);
    
    if (translatedRecipe) {
      console.log(`✅ Receta "${recipe.title}" completamente traducida al español`);
      return translatedRecipe;
    } else {
      console.log('⚠️ No se pudo traducir la receta, devolviendo original');
      return recipe;
    }
  } catch (error) {
    console.error('❌ Error en translateMealDbRecipe:', error);
    return recipe; // Devolver receta original en caso de error
  }
};

export const mealDbAPI = {
  // ✅ Buscar recetas por nombre - VERSIÓN SEGURA
  async searchRecipes(searchTerm: string): Promise<Recipe[]> {
    try {
      console.log('🔍 Buscando en TheMealDB:', searchTerm);
      
      if (!searchTerm || searchTerm.trim() === '') {
        console.log('⚠️ Término de búsqueda vacío');
        return [];
      }

      const response = await axios.get(`${API_BASE_URL}/search.php?s=${encodeURIComponent(searchTerm)}`);
      
      if (response.data && response.data.meals && Array.isArray(response.data.meals)) {
        // ✅ FILTRAR RECETAS VÁLIDAS
        const validRecipes = response.data.meals
          .map(mapMealToRecipe)
          .filter((recipe: Recipe | null): recipe is Recipe => recipe !== null);
        
        console.log(`✅ ${validRecipes.length} recetas válidas encontradas en TheMealDB`);
        
        // ✅ TRADUCIR RECETAS VÁLIDAS
        const translatedRecipes = await Promise.all(
          validRecipes.map(translateMealDbRecipe)
        );
        
        const finalRecipes = translatedRecipes.filter((recipe): recipe is Recipe => recipe !== null);
        console.log(`🌍 ${finalRecipes.length} recetas traducidas correctamente`);
        
        return finalRecipes;
      }
      
      console.log('❌ No se encontraron recetas en TheMealDB');
      return [];
    } catch (error) {
      console.error('❌ Error buscando recetas en TheMealDB:', error);
      return [];
    }
  },

  // ✅ Obtener recetas por categoría - VERSIÓN SEGURA
  async getRecipesByCategory(category: string): Promise<Recipe[]> {
    try {
      console.log('📁 Obteniendo recetas de categoría:', category);
      
      if (!category || category.trim() === '') {
        console.log('⚠️ Categoría vacía');
        return [];
      }

      const response = await axios.get(`${API_BASE_URL}/filter.php?c=${encodeURIComponent(category)}`);
      
      if (response.data && response.data.meals && Array.isArray(response.data.meals)) {
        // ✅ LIMITAR Y OBTENER DETALLES
        const mealPromises = response.data.meals.slice(0, 12).map(async (meal: any) => {
          try {
            if (!meal.idMeal) {
              console.log('⚠️ Meal sin ID:', meal);
              return null;
            }
            
            const detailResponse = await axios.get(`${API_BASE_URL}/lookup.php?i=${meal.idMeal}`);
            
            if (detailResponse.data && detailResponse.data.meals && detailResponse.data.meals[0]) {
              return mapMealToRecipe(detailResponse.data.meals[0]);
            }
            return null;
          } catch (error) {
            console.error('Error obteniendo detalle de receta:', error);
            return mapMealToRecipe(meal); // Intentar con datos básicos
          }
        });

        const detailedRecipes = (await Promise.all(mealPromises))
          .filter((recipe): recipe is Recipe => recipe !== null);
        
        console.log(`✅ ${detailedRecipes.length} recetas de ${category} cargadas`);
        
        // ✅ TRADUCIR RECETAS
        const translatedRecipes = await Promise.all(
          detailedRecipes.map(translateMealDbRecipe)
        );
        
        const finalRecipes = translatedRecipes.filter((recipe): recipe is Recipe => recipe !== null);
        return finalRecipes;
      }
      
      return [];
    } catch (error) {
      console.error('❌ Error obteniendo recetas por categoría:', error);
      return [];
    }
  },

  // ✅ Obtener receta por ID - VERSIÓN SEGURA
  async getRecipeById(id: string): Promise<Recipe | null> {
    try {
      console.log('📄 Obteniendo receta por ID:', id);
      
      if (!id || id.trim() === '') {
        console.log('⚠️ ID vacío');
        return null;
      }

      const response = await axios.get(`${API_BASE_URL}/lookup.php?i=${encodeURIComponent(id)}`);
      
      if (response.data && response.data.meals && response.data.meals[0]) {
        const recipe = mapMealToRecipe(response.data.meals[0]);
        
        if (recipe) {
          console.log('✅ Receta encontrada en TheMealDB, traduciendo...');
          return await translateMealDbRecipe(recipe);
        }
      }
      
      console.log('❌ Receta no encontrada en TheMealDB');
      return null;
    } catch (error) {
      console.error('❌ Error obteniendo receta por ID:', error);
      return null;
    }
  },

  // ✅ Obtener categorías disponibles - VERSIÓN SEGURA
  async getCategories(): Promise<{name: string; image: string}[]> {
    try {
      console.log('📋 Obteniendo categorías de TheMealDB');
      const response = await axios.get(`${API_BASE_URL}/categories.php`);
      
      if (response.data && response.data.categories && Array.isArray(response.data.categories)) {
        const categories = response.data.categories
          .filter((cat: any) => cat && cat.strCategory && cat.strCategoryThumb)
          .map((cat: any) => ({
            name: translateCategory(cat.strCategory),
            image: cat.strCategoryThumb
          }));
        
        console.log(`✅ ${categories.length} categorías cargadas`);
        return categories;
      }
      
      // ✅ CATEGORÍAS POR DEFECTO EN ESPAÑOL
      return [
        { name: 'Carne de Res', image: 'https://www.themealdb.com/images/category/beef.png' },
        { name: 'Pollo', image: 'https://www.themealdb.com/images/category/chicken.png' },
        { name: 'Postre', image: 'https://www.themealdb.com/images/category/dessert.png' },
        { name: 'Pasta', image: 'https://www.themealdb.com/images/category/pasta.png' },
        { name: 'Mariscos', image: 'https://www.themealdb.com/images/category/seafood.png' },
        { name: 'Vegetariano', image: 'https://www.themealdb.com/images/category/vegetarian.png' }
      ];
    } catch (error) {
      console.error('❌ Error obteniendo categorías, usando categorías por defecto:', error);
      return [
        { name: 'Carne de Res', image: 'https://www.themealdb.com/images/category/beef.png' },
        { name: 'Pollo', image: 'https://www.themealdb.com/images/category/chicken.png' },
        { name: 'Postre', image: 'https://www.themealdb.com/images/category/dessert.png' },
        { name: 'Pasta', image: 'https://www.themealdb.com/images/category/pasta.png' },
        { name: 'Mariscos', image: 'https://www.themealdb.com/images/category/seafood.png' }
      ];
    }
  },

  // ✅ Obtener recetas populares - VERSIÓN SEGURA
  async getPopularRecipes(): Promise<Recipe[]> {
    try {
      console.log('🔥 Obteniendo recetas populares de TheMealDB');
      
      // Usar recetas de categorías populares
      const response = await axios.get(`${API_BASE_URL}/filter.php?c=Chicken`);
      
      if (response.data && response.data.meals && Array.isArray(response.data.meals)) {
        const mealPromises = response.data.meals.slice(0, 8).map(async (meal: any) => {
          try {
            if (!meal.idMeal) return null;
            
            const detailResponse = await axios.get(`${API_BASE_URL}/lookup.php?i=${meal.idMeal}`);
            
            if (detailResponse.data && detailResponse.data.meals && detailResponse.data.meals[0]) {
              return mapMealToRecipe(detailResponse.data.meals[0]);
            }
            return null;
          } catch (error) {
            console.error('Error obteniendo receta popular:', error);
            return mapMealToRecipe(meal);
          }
        });

        const detailedRecipes = (await Promise.all(mealPromises))
          .filter((recipe): recipe is Recipe => recipe !== null);
        
        console.log(`✅ ${detailedRecipes.length} recetas populares cargadas`);
        
        // ✅ TRADUCIR RECETAS POPULARES
        const translatedRecipes = await Promise.all(
          detailedRecipes.map(translateMealDbRecipe)
        );
        
        const finalRecipes = translatedRecipes.filter((recipe): recipe is Recipe => recipe !== null);
        return finalRecipes;
      }
      
      return [];
    } catch (error) {
      console.error('❌ Error obteniendo recetas populares:', error);
      return [];
    }
  }
};