// src/services/api.ts - VERSIÓN COMPLETA CORREGIDA
import axios from 'axios';
import { AuthResponse, Recipe, RecipesResponse, User, UserProfileData } from '../types';
import { storage } from './storage';
import { apiNinjasAPI } from './apiNinjas';
import { translationService } from './translation';

// Configuración de URLs
const API_URLS = [
  'http://192.168.0.102:3001/api', // Tu IP real de Wi-Fi
  'http://10.0.2.2:3001/api', // Android emulator
  'http://localhost:3001/api', // iOS simulator
];

const DEVELOPMENT_MODE = false;

// Cache mejorado para recetas
let ninjasRecipesCache: Map<string, Recipe> = new Map();
let lastSearchResults: Recipe[] = [];
let searchCache: Map<string, Recipe[]> = new Map();

// TRADUCCIÓN COMPLETA DE INGREDIENTES
const translateIngredient = (ingredient: string): string => {
  const translations: { [key: string]: string } = {
    // Ingredientes básicos
    'salt': 'sal', 'pepper': 'pimienta', 'sugar': 'azúcar', 'flour': 'harina',
    'butter': 'mantequilla', 'oil': 'aceite', 'garlic': 'ajo', 'onion': 'cebolla',
    'tomato': 'tomate', 'egg': 'huevo', 'milk': 'leche', 'water': 'agua',
    'rice': 'arroz', 'chicken': 'pollo', 'beef': 'carne de res', 'pork': 'cerdo',
    'fish': 'pescado', 'cheese': 'queso', 'bread': 'pan', 'lemon': 'limón',
    'carrot': 'zanahoria', 'potato': 'papa', 'bell pepper': 'pimiento',
    
    // Hierbas y especias
    'parsley': 'perejil', 'basil': 'albahaca', 'oregano': 'orégano',
    'thyme': 'tomillo', 'rosemary': 'romero', 'cumin': 'comino',
    'paprika': 'pimentón', 'cinnamon': 'canela', 'nutmeg': 'nuez moscada',
    'coriander': 'cilantro', 'chili': 'chile', 'ginger': 'jengibre',
    
    // Lácteos y derivados
    'cream': 'crema', 'yogurt': 'yogur', 'buttermilk': 'suero de leche',
    
    // Frutas
    'apple': 'manzana', 'banana': 'plátano', 'orange': 'naranja',
    'lime': 'lima', 'avocado': 'aguacate', 'coconut': 'coco',
    
    // Verduras
    'spinach': 'espinaca', 'lettuce': 'lechuga', 'cucumber': 'pepino',
    'mushroom': 'champiñón', 'broccoli': 'brócoli', 'cauliflower': 'coliflor',
    'cabbage': 'repollo', 'celery': 'apio', 'asparagus': 'espárrago',
    
    // Carnes y pescados
    'lamb': 'cordero', 'duck': 'pato', 'turkey': 'pavo',
    'salmon': 'salmón', 'tuna': 'atún', 'shrimp': 'camarón',
    'crab': 'cangrejo', 'lobster': 'langosta',
    
    // Granos y legumbres
    'pasta': 'pasta', 'noodles': 'fideos', 'beans': 'frijoles',
    'lentils': 'lentejas', 'chickpeas': 'garbanzos',
    
    // Frutos secos
    'almond': 'almendra', 'peanut': 'cacahuate', 'walnut': 'nuez',
    'hazelnut': 'avellana', 'pecan': 'nuez pecana',
    
    // Bebidas y líquidos
    'vinegar': 'vinagre', 'soy sauce': 'salsa de soya', 'wine': 'vino',
    'beer': 'cerveza', 'stock': 'caldo', 'broth': 'caldo'
  };
  
  const lowerIngredient = ingredient.toLowerCase().trim();
  return translations[lowerIngredient] || ingredient;
};

// TRADUCCIÓN COMPLETA DE INSTRUCCIONES
const translateInstruction = (instruction: string): string => {
  const translations: { [key: string]: string } = {
    'Preheat oven': 'Precalentar el horno',
    'Preheat the oven': 'Precalentar el horno',
    'In a large bowl': 'En un tazón grande',
    'In a medium bowl': 'En un tazón mediano', 
    'In a small bowl': 'En un tazón pequeño',
    'Add the': 'Agregar el',
    'Add': 'Agregar',
    'Mix well': 'Mezclar bien',
    'Stir until combined': 'Revolver hasta que esté combinado',
    'Cook until done': 'Cocinar hasta que esté listo',
    'Serve immediately': 'Servir inmediatamente',
    'Garnish with': 'Decorar con',
    'Season with salt and pepper': 'Sazonar con sal y pimienta',
    'Heat the oil': 'Calentar el aceite',
    'Chop the': 'Picar el',
    'Slice the': 'Cortar en rodajas el',
    'Dice the': 'Cortar en cubos el',
    'Bake for': 'Hornear durante',
    'Fry until golden': 'Freír hasta que esté dorado',
    'Boil the': 'Hervir el',
    'Simmer for': 'Cocinar a fuego lento durante',
    'Whisk together': 'Batir juntos',
    'Knead the dough': 'Amasar la masa',
    'Let it rest': 'Dejar reposar',
    'Marinate for': 'Marinar durante',
    'Grill for': 'Asar a la parrilla durante',
    'Roast in the oven': 'Asar en el horno',
    'Drain well': 'Escurrir bien',
    'Cut into pieces': 'Cortar en pedazos',
    'Mix thoroughly': 'Mezclar completamente',
    'Bring to a boil': 'Llevar a ebullición',
    'Reduce heat': 'Reducir el fuego',
    'Cover and cook': 'Tapar y cocinar',
    'Remove from heat': 'Retirar del fuego',
    'Set aside': 'Reservar',
    'Sprinkle with': 'Espolvorear con',
    'Pour over': 'Verter sobre',
    'Spread evenly': 'Extender uniformemente',
    'Beat until smooth': 'Batir hasta que esté suave',
    'Fold in': 'Incorporar suavemente',
    'Grease the pan': 'Engrasar la sartén',
    'Line with parchment': 'Forrar con papel pergamino'
  };

  let translated = instruction;
  
  // Reemplazar frases completas
  Object.keys(translations).forEach(english => {
    const regex = new RegExp(english, 'gi');
    translated = translated.replace(regex, translations[english]);
  });
  
  // Reemplazar palabras individuales
  translated = translated.split(' ').map(word => translateIngredient(word)).join(' ');
  
  return translated;
};

// CATEGORÍAS EN ESPAÑOL
const translateCategory = (category: string): string => {
  const translations: { [key: string]: string } = {
    'Beef': 'Carne de Res',
    'Chicken': 'Pollo',
    'Dessert': 'Postre',
    'Lamb': 'Cordero', 
    'Miscellaneous': 'Variado',
    'Pasta': 'Pasta',
    'Pork': 'Cerdo',
    'Seafood': 'Mariscos',
    'Side': 'Acompañamiento',
    'Starter': 'Entrada',
    'Vegan': 'Vegano',
    'Vegetarian': 'Vegetariano',
    'Breakfast': 'Desayuno',
    'Goat': 'Cabra'
  };
  return translations[category] || category;
};

// MAPEAR RECETA CON TRADUCCIÓN COMPLETA
const mapMealToRecipe = (meal: any): Recipe => {
  const ingredients: any[] = [];
  
  // Extraer y traducir ingredientes
  for (let i = 1; i <= 20; i++) {
    const ingredient = meal[`strIngredient${i}`];
    const measure = meal[`strMeasure${i}`];
    
    if (ingredient && ingredient.trim()) {
      ingredients.push({
        name: translateIngredient(ingredient),
        quantity: measure ? translateIngredient(measure) : '',
        unit: ''
      });
    }
  }

  // Traducir instrucciones completamente
  const instructions = meal.strInstructions 
    ? meal.strInstructions
        .split('\r\n')
        .filter((step: string) => step.trim())
        .map((step: string, index: number) => ({
          step: index + 1,
          description: translateInstruction(step)
        }))
    : [];

  return {
    _id: meal.idMeal,
    title: meal.strMeal,
    description: `Deliciosa receta de ${meal.strMeal}. ${translateCategory(meal.strCategory)} perfecta para cualquier ocasión.`,
    ingredients,
    instructions,
    preparationTime: 30,
    difficulty: 'Media',
    category: translateCategory(meal.strCategory),
    image: meal.strMealThumb,
    author: {
      id: 'themealdb',
      username: 'TheMealDB',
      email: 'info@themealdb.com'
    },
    ratings: [],
    createdAt: new Date().toISOString()
  };
};

// RECETAS DE EJEMPLO EN ESPAÑOL
const SAMPLE_RECIPES: Recipe[] = [
  {
    _id: '1',
    title: 'Tacos de Pescado con Especias Cajún',
    description: 'Deliciosos tacos de pescado con una mezcla de especias cajún. Perfectos para una comida rápida y llena de sabor.',
    ingredients: [
      { name: 'filetes de pescado blanco', quantity: '4', unit: '' },
      { name: 'mezcla de especias cajún', quantity: '2', unit: 'cucharadas' },
      { name: 'pimienta de cayena', quantity: '1', unit: 'cucharadita' },
      { name: 'aceite vegetal', quantity: '1', unit: 'cucharadita' },
      { name: 'tortillas de harina', quantity: '8', unit: '' },
      { name: 'aguacate en rodajas', quantity: '1', unit: '' },
      { name: 'lechuga desmenuzada', quantity: '2', unit: 'tazas' },
      { name: 'cebolletas', quantity: '4', unit: '' },
      { name: 'salsa', quantity: '300', unit: 'ml' },
      { name: 'crema agria', quantity: '1', unit: 'pote' }
    ],
    instructions: [
      { 
        step: 1, 
        description: 'En un plato grande, mezclar las especias cajún y la pimienta de cayena con un poco de condimento y usar para cubir el pescado por completo.' 
      },
      { 
        step: 2, 
        description: 'Calentar un poco de aceite en una sartén, agregar el pescado y cocinar a fuego medio hasta que esté dorado.' 
      },
      { 
        step: 3, 
        description: 'Reducir el calor y continuar friendo hasta que el pescado esté cocido completamente, aproximadamente 10 minutos.' 
      },
      { 
        step: 4, 
        description: 'Mientras tanto, preparar el aderezo combinando todos los ingredientes con un poco de condimento.' 
      },
      { 
        step: 5, 
        description: 'Servir el pescado en tortillas calientes con aguacate, lechuga, cebolletas y los aderezos.' 
      }
    ],
    preparationTime: 30,
    difficulty: 'Media',
    category: 'Mariscos',
    image: 'https://www.themealdb.com/images/media/meals/1520081754.jpg',
    author: {
      id: 'chef1',
      username: 'Chef Internacional',
      email: 'chef@recetas.com'
    },
    ratings: [],
    createdAt: new Date().toISOString()
  },
  {
    _id: '2',
    title: 'Ensalada César con Pollo',
    description: 'Ensalada fresca con pollo a la parrilla, crutones crujientes y aderezo césar casero.',
    ingredients: [
      { name: 'pechuga de pollo', quantity: '2', unit: '' },
      { name: 'lechuga romana', quantity: '1', unit: 'cabeza' },
      { name: 'crutones', quantity: '1', unit: 'taza' },
      { name: 'queso parmesano', quantity: '1/2', unit: 'taza' },
      { name: 'limón', quantity: '1', unit: '' },
      { name: 'aceite de oliva', quantity: '3', unit: 'cucharadas' },
      { name: 'ajo', quantity: '2', unit: 'dientes' },
      { name: 'anchoas', quantity: '4', unit: '' }
    ],
    instructions: [
      { step: 1, description: 'Sazonar el pollo con sal y pimienta, luego cocinar a la parrilla hasta que esté dorado y cocido.' },
      { step: 2, description: 'Lavar y cortar la lechuga romana en trozos del tamaño de un bocado.' },
      { step: 3, description: 'Preparar el aderezo césar mezclando ajo, anchoas, jugo de limón y aceite de oliva.' },
      { step: 4, description: 'Cortar el pollo en tiras y mezclar con la lechuga, crutones y aderezo.' },
      { step: 5, description: 'Espolvorear queso parmesano rallado y servir inmediatamente.' }
    ],
    preparationTime: 20,
    difficulty: 'Fácil',
    category: 'Ensalada',
    image: 'https://www.themealdb.com/images/media/meals/1520081754.jpg',
    author: {
      id: 'chef2',
      username: 'Chef Italiano',
      email: 'chef@recetas.com'
    },
    ratings: [],
    createdAt: new Date().toISOString()
  }
];

// MOCK API PARA DESARROLLO - CORREGIDO
const mockAuthAPI = {
  async login(email: string, password: string): Promise<AuthResponse> {
    console.log('🔐 MODO DESARROLLO: Login simulado');
    
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Validación básica
    if (!email || !password) {
      throw new Error('Email y contraseña son requeridos');
    }
    
    if (password.length < 6) {
      throw new Error('La contraseña debe tener al menos 6 caracteres');
    }
    
    if (!email.includes('@')) {
      throw new Error('Email inválido');
    }
    
    const mockUser: User = {
      id: 'dev_user_1',
      username: email.split('@')[0] || 'usuario',
      email: email,
      profile: {
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      }
    };
    
    return {
      message: 'Login exitoso (modo desarrollo)',
      token: 'dev_jwt_token_' + Date.now(),
      user: mockUser
    };
  },

  async register(username: string, email: string, password: string): Promise<AuthResponse> {
    console.log('📝 MODO DESARROLLO: Registro simulado');
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Validación básica
    if (!username || !email || !password) {
      throw new Error('Todos los campos son requeridos');
    }
    
    if (username.length < 3) {
      throw new Error('El usuario debe tener al menos 3 caracteres');
    }
    
    if (password.length < 6) {
      throw new Error('La contraseña debe tener al menos 6 caracteres');
    }
    
    if (!email.includes('@')) {
      throw new Error('Email inválido');
    }
    
    const mockUser: User = {
      id: 'dev_user_' + Date.now(),
      username: username,
      email: email,
      profile: {
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      }
    };
    
    return {
      message: 'Registro exitoso (modo desarrollo)',
      token: 'dev_jwt_token_' + Date.now(),
      user: mockUser
    };
  },

  async getCurrentUser(): Promise<User> {
    const user = await storage.getUser();
    if (!user) {
      throw new Error('No hay usuario autenticado');
    }
    return user;
  },

  async getProfile(): Promise<UserProfileData> {
    const user = await storage.getUser();
    if (!user || !user.profile) {
      return {
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      };
    }
    return user.profile;
  },

  async updateProfile(profile: UserProfileData): Promise<User> {
    const user = await storage.getUser();
    if (!user) {
      throw new Error('No hay usuario autenticado');
    }
    
    const updatedUser: User = {
      ...user,
      profile: profile
    };
    
    await storage.saveUser(updatedUser);
    return updatedUser;
  }
};

const detectBaseURL = async (): Promise<string> => {
  console.log('🔍 Detectando URL del backend...');
  
  // Probar solo la primera URL sin verificar /health
  const testURL = API_URLS[0];
  try {
    console.log(`   Probando: ${testURL}`);
    // Intentar una conexión básica
    await axios.get(testURL, { timeout: 3000 });
    console.log(`✅✅✅ CONEXIÓN EXITOSA: ${testURL}`);
    return testURL;
  } catch (error) {
    console.log(`   ❌ No se pudo conectar: ${testURL}`);
  }
  
  console.warn('⚠️ No se pudo conectar al backend - Usando MODO DESARROLLO');
  return API_URLS[0];
};

// Variable global para la URL base
let API_BASE_URL = API_URLS[0];

// Cliente HTTP mejorado
export const apiRequest = async (endpoint: string, options: any = {}) => {
  // Si estamos en modo desarrollo, usar mock API para auth
  if (DEVELOPMENT_MODE && (endpoint.includes('/auth/') || endpoint.includes('/profile'))) {
    console.log(`🛠️  MODO DESARROLLO: Usando mock para ${endpoint}`);
    throw new Error('Backend no disponible - Modo desarrollo activo');
  }

  try {
    const token = await storage.getToken();
    
    const config = {
      baseURL: API_BASE_URL,
      timeout: 15000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers,
      },
      ...options,
    };

    console.log(`🌐 Haciendo request a: ${API_BASE_URL}${endpoint}`);
    
    const response = await axios({
      url: endpoint,
      ...config,
    });

    console.log(`✅ Request exitoso: ${endpoint}`);
    return response.data;
  } catch (error: any) {
    console.error(`❌ Error en request ${endpoint}:`, error.message);
    
    if (error.code === 'ECONNREFUSED') {
      throw new Error(`No se puede conectar al servidor en ${API_BASE_URL}. Verifica que el backend esté ejecutándose.`);
    }
    
    if (error.message?.includes('Network Error') || error.message?.includes('ENETUNREACH')) {
      throw new Error(`Error de red. No se puede conectar a ${API_BASE_URL}. Verifica:
• Backend ejecutándose en puerto 3001
• Misma red Wi-Fi
• Firewall de Windows
• IP correcta: 192.168.0.102`);
    }
    
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    }
    
    throw new Error(error.message || 'Error de conexión con el servidor');
  }
};

// Inicializar la detección de URL al cargar el módulo
(async () => {
  if (!DEVELOPMENT_MODE) {
    console.log('🚀 Inicializando detección de backend...');
    API_BASE_URL = await detectBaseURL();
  } else {
    console.log('🛠️  MODO DESARROLLO ACTIVADO - Usando datos mock');
  }
})();

// ESTRATEGIA DE BÚSQUEDA MEJORADA CON CACHÉ
const searchRecipesStrategy = async (params: any): Promise<Recipe[]> => {
  let recipes: Recipe[] = [];
  
  // Verificar caché de búsqueda primero
  const cacheKey = `${params.search || ''}-${params.category || ''}`;
  if (searchCache.has(cacheKey)) {
    console.log('📦 Usando resultados de caché de búsqueda');
    return searchCache.get(cacheKey)!;
  }
  
  // PRIMERO: Intentar con API Ninjas
  try {
    console.log('🔄 Intentando buscar con API Ninjas...');
    
    if (params.search) {
      recipes = await apiNinjasAPI.searchRecipes(params.search);
    } else if (params.category && params.category !== 'Popular') {
      recipes = await apiNinjasAPI.getRecipesByCategory(params.category);
    }
    
    // Si API Ninjas devuelve resultados, usarlos
    if (recipes.length > 0) {
      console.log(`✅ API Ninjas devolvió ${recipes.length} recetas`);
      // Guardar en caché de búsqueda
      searchCache.set(cacheKey, recipes);
      // Guardar en caché individual
      recipes.forEach(recipe => ninjasRecipesCache.set(recipe._id, recipe));
      lastSearchResults = recipes;
      return recipes;
    } else {
      console.log('🔄 API Ninjas no devolvió resultados, usando respaldo...');
    }
  } catch (error) {
    console.log('❌ API Ninjas no disponible, intentando con respaldo...');
  }
  
  // SEGUNDO: Si API Ninjas falla, usar TheMealDB como respaldo
  try {
    console.log('🔄 Usando TheMealDB como respaldo...');
    
    if (params.search) {
      const response = await axios.get(`https://www.themealdb.com/api/json/v1/1/search.php?s=${params.search}`);
      if (response.data.meals) {
        recipes = response.data.meals.map(mapMealToRecipe);
      }
    } else if (params.category && params.category !== 'Popular') {
      const categoryMap: { [key: string]: string } = {
        'Carne de Res': 'Beef',
        'Pollo': 'Chicken',
        'Postre': 'Dessert',
        'Pasta': 'Pasta', 
        'Mariscos': 'Seafood',
        'Vegetariano': 'Vegetarian',
        'Desayuno': 'Breakfast',
        'Entrada': 'Starter',
        'Cerdo': 'Pork',
        'Cordero': 'Lamb'
      };
      const englishCategory = categoryMap[params.category] || params.category;
      const response = await axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${englishCategory}`);
      
      if (response.data.meals) {
        const detailedRecipes = await Promise.all(
          response.data.meals.slice(0, 8).map(async (meal: any) => {
            try {
              const detailResponse = await axios.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`);
              return mapMealToRecipe(detailResponse.data.meals[0]);
            } catch (error) {
              console.error('Error obteniendo receta detallada:', error);
              return null;
            }
          })
        );
        recipes = detailedRecipes.filter(recipe => recipe !== null) as Recipe[];
      }
    }
  } catch (error) {
    console.error('❌ Error con TheMealDB:', error);
  }
  
  // TERCERO: Si todo falla, usar recetas de ejemplo
  if (recipes.length === 0) {
    console.log('🔄 Usando recetas de ejemplo...');
    recipes = SAMPLE_RECIPES.filter(recipe => {
      if (params.search) {
        return recipe.title.toLowerCase().includes(params.search.toLowerCase()) ||
               recipe.description.toLowerCase().includes(params.search.toLowerCase());
      }
      if (params.category && params.category !== 'Popular') {
        return recipe.category === params.category;
      }
      return true;
    });
  }
  
  // Guardar en cachés
  searchCache.set(cacheKey, recipes);
  recipes.forEach(recipe => ninjasRecipesCache.set(recipe._id, recipe));
  lastSearchResults = recipes;
  
  return recipes;
};

export const authAPI = {
  async login(email: string, password: string): Promise<AuthResponse> {
    if (DEVELOPMENT_MODE) {
      return mockAuthAPI.login(email, password);
    }

    try {
      console.log('🔐 Iniciando sesión con backend real...');
      
      const data = await apiRequest('/auth/login', {
        method: 'POST',
        data: {
          email: email.toLowerCase().trim(),
          password
        }
      });

      if (!data.success) {
        throw new Error(data.message || 'Error al iniciar sesión');
      }

      console.log('✅ Login exitoso, cargando perfil completo...');
      
      // GUARDAR USUARIO Y TOKEN INMEDIATAMENTE
      await storage.saveToken(data.token);
      await storage.saveUser(data.user);

      // CARGAR PERFIL COMPLETO DESPUÉS DEL LOGIN
      try {
        const userProfile = await this.getProfile();
        const userWithProfile = {
          ...data.user,
          profile: userProfile
        };
        
        // ACTUALIZAR USUARIO CON PERFIL COMPLETO
        await storage.saveUser(userWithProfile);
        
        console.log('✅ Perfil completo cargado después del login');
        
        return {
          message: data.message,
          token: data.token,
          user: userWithProfile
        };
      } catch (profileError) {
        console.warn('⚠️ No se pudo cargar el perfil completo:', profileError);
        // Devolver usuario básico si falla la carga del perfil
        return {
          message: data.message,
          token: data.token,
          user: data.user
        };
      }
    } catch (error: any) {
      console.error('Error en login:', error);
      throw new Error(error.message);
    }
  },

  async register(username: string, email: string, password: string): Promise<AuthResponse> {
    if (DEVELOPMENT_MODE) {
      return mockAuthAPI.register(username, email, password);
    }

    try {
      console.log('📝 Registrando usuario con backend real...');
      
      const data = await apiRequest('/auth/register', {
        method: 'POST',
        data: {
          username: username.trim(),
          email: email.toLowerCase().trim(),
          password
        }
      });

      if (!data.success) {
        throw new Error(data.message || 'Error al registrar usuario');
      }

      console.log('✅ Registro exitoso');
      return {
        message: data.message,
        token: data.token,
        user: data.user
      };
    } catch (error: any) {
      console.error('Error en registro:', error);
      throw new Error(error.message);
    }
  },

  async getCurrentUser(): Promise<User> {
    if (DEVELOPMENT_MODE) {
      return mockAuthAPI.getCurrentUser();
    }

    try {
      console.log('👤 Obteniendo usuario actual...');
      
      // Primero obtener datos básicos del usuario
      const userData = await apiRequest('/auth/me', {
        method: 'GET'
      });

      if (!userData.success) {
        throw new Error(userData.message || 'Error obteniendo usuario');
      }

      console.log('✅ Datos básicos del usuario obtenidos');
      
      // Luego obtener perfil completo
      try {
        const profileData = await this.getProfile();
        const completeUser: User = {
          ...userData.user,
          profile: profileData
        };
        
        // Guardar usuario completo en storage
        await storage.saveUser(completeUser);
        
        console.log('✅ Perfil completo cargado y guardado');
        return completeUser;
      } catch (profileError) {
        console.warn('⚠️ No se pudo cargar perfil completo, usando datos básicos:', profileError);
        return userData.user;
      }
    } catch (error: any) {
      console.error('Error obteniendo usuario:', error);
      throw new Error(error.message);
    }
  },

  async getProfile(): Promise<UserProfileData> {
    if (DEVELOPMENT_MODE) {
      return mockAuthAPI.getProfile();
    }

    try {
      console.log('📋 Obteniendo perfil completo...');
      
      const data = await apiRequest('/profile', {
        method: 'GET'
      });

      if (!data.success) {
        throw new Error(data.message || 'Error obteniendo perfil');
      }

      console.log('✅ Perfil obtenido exitosamente');
      
      // Asegurar estructura correcta
      const profile: UserProfileData = {
        personalInfo: data.profile?.personalInfo || {},
        healthInfo: {
          allergies: data.profile?.healthInfo?.allergies || [],
          dietaryRestrictions: data.profile?.healthInfo?.dietaryRestrictions || [],
          healthConditions: data.profile?.healthInfo?.healthConditions || [],
          healthGoals: data.profile?.healthInfo?.healthGoals || []
        },
        preferences: data.profile?.preferences || {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      };

      return profile;
    } catch (error: any) {
      console.error('Error obteniendo perfil:', error);
      throw new Error(error.message);
    }
  },

  async updateProfile(profile: UserProfileData): Promise<User> {
    if (DEVELOPMENT_MODE) {
      return mockAuthAPI.updateProfile(profile);
    }

    try {
      const data = await apiRequest('/profile', {
        method: 'PUT',
        data: { profile }
      });

      if (!data.success) {
        throw new Error(data.message || 'Error actualizando perfil');
      }

      return data.user;
    } catch (error: any) {
      console.error('Error actualizando perfil:', error);
      throw new Error(error.message);
    }
  },

  async updateProfilePartial(updates: Partial<UserProfileData>): Promise<User> {
    if (DEVELOPMENT_MODE) {
      const currentProfile = await mockAuthAPI.getProfile();
      const newProfile = { ...currentProfile, ...updates };
      return mockAuthAPI.updateProfile(newProfile);
    }

    try {
      console.log('🔄 Actualizando perfil parcial:', Object.keys(updates));
      
      // Determinar qué endpoint usar basado en los campos a actualizar
      let endpoint = '/profile';
      let method = 'PATCH';
      
      if (updates.personalInfo && Object.keys(updates.personalInfo).length > 0) {
        endpoint = '/profile/personal';
        method = 'PATCH';
      } else if (updates.healthInfo && Object.keys(updates.healthInfo).length > 0) {
        endpoint = '/profile/health';
        method = 'PATCH';
      }

      const data = await apiRequest(endpoint, {
        method: method,
        data: updates
      });

      if (!data.success) {
        throw new Error(data.message || 'Error actualizando perfil');
      }

      console.log('✅ Perfil parcial actualizado exitosamente');

      // Devolver usuario actualizado
      const currentUser = await storage.getUser();
      const updatedUser: User = {
        ...currentUser!,
        profile: data.profile
      };

      await storage.saveUser(updatedUser);
      return updatedUser;
    } catch (error: any) {
      console.error('Error actualizando perfil parcial:', error);
      throw new Error(error.message);
    }
  },

  // Función para cargar perfil completo
  async loadCompleteUserProfile(): Promise<User> {
    try {
      const user = await storage.getUser();
      if (!user) {
        throw new Error('No hay usuario autenticado');
      }

      console.log('📥 Cargando perfil completo del usuario...');
      
      // Cargar perfil desde el backend
      const profile = await this.getProfile();
      
      const completeUser: User = {
        ...user,
        profile: profile
      };
      
      // Guardar usuario completo en storage
      await storage.saveUser(completeUser);
      
      console.log('✅ Perfil completo cargado exitosamente');
      return completeUser;
    } catch (error) {
      console.error('❌ Error cargando perfil completo:', error);
      throw error;
    }
  }
};

export const recipesAPI = {
  async getAllRecipes(params?: { 
    category?: string; 
    search?: string; 
    page?: number;
    cuisine?: string;
    diet?: string;
  }): Promise<RecipesResponse> {
    try {
      let recipes: Recipe[] = [];

      console.log('🔍 Iniciando búsqueda de recetas...');

      // USAR LA ESTRATEGIA DE BÚSQUEDA MEJORADA
      if (params?.search || (params?.category && params.category !== 'Popular')) {
        recipes = await searchRecipesStrategy({
          search: params.search,
          category: params.category
        });
      } else {
        // Para recetas populares, usar API Ninjas
        console.log('🔥 Cargando recetas populares...');
        try {
          recipes = await apiNinjasAPI.getPopularRecipes();
        } catch (error) {
          console.log('❌ API Ninjas falló, usando TheMealDB...');
        }
        
        // Si API Ninjas falla, usar TheMealDB
        if (recipes.length === 0) {
          try {
            const response = await axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?c=Beef`);
            if (response.data.meals) {
              const detailedRecipes = await Promise.all(
                response.data.meals.slice(0, 8).map(async (meal: any) => {
                  try {
                    const detailResponse = await axios.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`);
                    return mapMealToRecipe(detailResponse.data.meals[0]);
                  } catch (error) {
                    return null;
                  }
                })
              );
              recipes = detailedRecipes.filter(recipe => recipe !== null) as Recipe[];
            }
          } catch (error) {
            console.error('❌ TheMealDB también falló:', error);
          }
        }
        
        // Guardar en caché
        recipes.forEach(recipe => ninjasRecipesCache.set(recipe._id, recipe));
        lastSearchResults = recipes;
      }

      // SI NO HAY RESULTADOS, USAR RECETAS DE EJEMPLO
      if (recipes.length === 0) {
        console.log('🔄 Usando recetas de ejemplo en español...');
        recipes = SAMPLE_RECIPES;
      }

      console.log(`✅ Búsqueda completada: ${recipes.length} recetas encontradas`);

      return {
        recipes,
        totalPages: 1,
        currentPage: params?.page || 1,
        total: recipes.length
      };
    } catch (error) {
      console.error('❌ Error en búsqueda principal, usando recetas de ejemplo:', error);
      return {
        recipes: SAMPLE_RECIPES,
        totalPages: 1,
        currentPage: 1,
        total: SAMPLE_RECIPES.length
      };
    }
  },

  async getRecipeById(id: string): Promise<Recipe> {
    try {
      console.log(`📄 Obteniendo receta: ${id}`);
      
      // 1. Buscar en caché de API Ninjas
      if (ninjasRecipesCache.has(id)) {
        console.log('✅ Receta encontrada en caché');
        const cachedRecipe = ninjasRecipesCache.get(id)!;
        
        // APLICAR TRADUCCIÓN COMPLETA si está en español
        if (translationService.getCurrentLanguage() === 'es') {
          console.log('🔄 Aplicando traducción COMPLETA a receta en caché...');
          
          try {
            const fullyTranslatedRecipe = await translationService.translateRecipe(cachedRecipe);
            console.log('✅ Receta de caché completamente traducida al español');
            return fullyTranslatedRecipe;
          } catch (translationError) {
            console.error('❌ Error en traducción completa, usando traducción local:', translationError);
            
            // Fallback: traducción local inmediata
            const locallyTranslatedRecipe = {
              ...cachedRecipe,
              title: translationService.translateLocally(cachedRecipe.title),
              description: translationService.translateLocally(cachedRecipe.description),
              ingredients: await Promise.all(
                cachedRecipe.ingredients.map(async (ing: any) => ({
                  ...ing,
                  name: translationService.translateLocally(ing.name),
                  quantity: translationService.translateLocally(ing.quantity),
                  unit: translationService.translateLocally(ing.unit)
                }))
              ),
              instructions: await Promise.all(
                cachedRecipe.instructions.map(async (inst: any) => ({
                  ...inst,
                  description: translationService.translateLocally(inst.description)
                }))
              ),
              category: translationService.translateLocally(cachedRecipe.category),
              difficulty: translationService.translateLocally(cachedRecipe.difficulty) as "Fácil" | "Media" | "Difícil"
            };
            
            return locallyTranslatedRecipe;
          }
        }
        
        return cachedRecipe;
      }
      
      // 2. Buscar en resultados de búsqueda recientes
      const recentRecipe = lastSearchResults.find(recipe => recipe._id === id);
      if (recentRecipe) {
        console.log('✅ Receta encontrada en búsqueda reciente');
        ninjasRecipesCache.set(id, recentRecipe);
        
        // APLICAR TRADUCCIÓN COMPLETA si está en español
        if (translationService.getCurrentLanguage() === 'es') {
          console.log('🔄 Aplicando traducción COMPLETA a receta reciente...');
          
          try {
            const fullyTranslatedRecipe = await translationService.translateRecipe(recentRecipe);
            console.log('✅ Receta reciente completamente traducida al español');
            return fullyTranslatedRecipe;
          } catch (translationError) {
            console.error('❌ Error en traducción completa, usando traducción local:', translationError);
            
            // Fallback: traducción local inmediata
            const locallyTranslatedRecipe = {
              ...recentRecipe,
              title: translationService.translateLocally(recentRecipe.title),
              description: translationService.translateLocally(recentRecipe.description),
              ingredients: await Promise.all(
                recentRecipe.ingredients.map(async (ing: any) => ({
                  ...ing,
                  name: translationService.translateLocally(ing.name),
                  quantity: translationService.translateLocally(ing.quantity),
                  unit: translationService.translateLocally(ing.unit)
                }))
              ),
              instructions: await Promise.all(
                recentRecipe.instructions.map(async (inst: any) => ({
                  ...inst,
                  description: translationService.translateLocally(inst.description)
                }))
              ),
              category: translationService.translateLocally(recentRecipe.category),
              difficulty: translationService.translateLocally(recentRecipe.difficulty) as "Fácil" | "Media" | "Difícil"
            };
            
            return locallyTranslatedRecipe;
          }
        }
        
        return recentRecipe;
      }
      
      // 3. Buscar en recetas de ejemplo
      const sampleRecipe = SAMPLE_RECIPES.find(recipe => recipe._id === id);
      if (sampleRecipe) {
        console.log('✅ Receta encontrada en ejemplos');
        
        // Las recetas de ejemplo ya están en español, pero aplicar traducción si es necesario
        if (translationService.getCurrentLanguage() === 'es') {
          console.log('🔄 Verificando traducción de receta de ejemplo...');
          const verifiedRecipe = await translationService.translateRecipe(sampleRecipe);
          return verifiedRecipe;
        }
        
        return sampleRecipe;
      }
      
      // 4. Si es API Ninjas pero no está en caché
      if (id.startsWith('ninjas-')) {
        console.log('❌ Receta de API Ninjas no encontrada en caché');
        
        // Intentar buscar recetas similares
        if (lastSearchResults.length > 0) {
          console.log('🔄 Usando receta de búsqueda reciente como fallback');
          const fallbackRecipe = lastSearchResults[0];
          ninjasRecipesCache.set(id, fallbackRecipe);
          
          // APLICAR TRADUCCIÓN COMPLETA si está en español
          if (translationService.getCurrentLanguage() === 'es') {
            console.log('🔄 Aplicando traducción COMPLETA a receta de fallback...');
            
            try {
              const fullyTranslatedRecipe = await translationService.translateRecipe(fallbackRecipe);
              console.log('✅ Receta de fallback completamente traducida al español');
              return fullyTranslatedRecipe;
            } catch (translationError) {
              console.error('❌ Error en traducción completa, usando traducción local:', translationError);
              
              // Fallback: traducción local inmediata
              const locallyTranslatedRecipe = {
                ...fallbackRecipe,
                title: translationService.translateLocally(fallbackRecipe.title),
                description: translationService.translateLocally(fallbackRecipe.description),
                ingredients: await Promise.all(
                  fallbackRecipe.ingredients.map(async (ing: any) => ({
                    ...ing,
                    name: translationService.translateLocally(ing.name),
                    quantity: translationService.translateLocally(ing.quantity),
                    unit: translationService.translateLocally(ing.unit)
                  }))
                ),
                instructions: await Promise.all(
                  fallbackRecipe.instructions.map(async (inst: any) => ({
                    ...inst,
                    description: translationService.translateLocally(inst.description)
                  }))
                ),
                category: translationService.translateLocally(fallbackRecipe.category),
                difficulty: translationService.translateLocally(fallbackRecipe.difficulty) as "Fácil" | "Media" | "Difícil"
              };
              
              return locallyTranslatedRecipe;
            }
          }
          
          return fallbackRecipe;
        }
        
        throw new Error('Receta no encontrada. Por favor, realiza una nueva búsqueda.');
      }
      
      // 5. Buscar en TheMealDB
      console.log('🔄 Buscando en TheMealDB...');
      const response = await axios.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`);
      if (response.data.meals && response.data.meals[0]) {
        const mealDBRecipe = mapMealToRecipe(response.data.meals[0]);
        
        // APLICAR TRADUCCIÓN COMPLETA si está en español
        if (translationService.getCurrentLanguage() === 'es') {
          console.log('🔄 Aplicando traducción COMPLETA a receta de TheMealDB...');
          
          try {
            const fullyTranslatedRecipe = await translationService.translateRecipe(mealDBRecipe);
            console.log('✅ Receta de TheMealDB completamente traducida al español');
            return fullyTranslatedRecipe;
          } catch (translationError) {
            console.error('❌ Error en traducción completa, usando receta base:', translationError);
            return mealDBRecipe; // Devolver sin traducción si falla
          }
        }
        
        return mealDBRecipe;
      }
      
      throw new Error('Receta no encontrada');
    } catch (error) {
      console.error('❌ Error obteniendo receta:', error);
      
      // Intentar devolver una receta de ejemplo como último recurso
      if (SAMPLE_RECIPES.length > 0) {
        console.log('🔄 Usando receta de ejemplo como último recurso');
        const fallbackRecipe = SAMPLE_RECIPES[0];
        
        if (translationService.getCurrentLanguage() === 'es') {
          try {
            return await translationService.translateRecipe(fallbackRecipe);
          } catch {
            return fallbackRecipe;
          }
        }
        
        return fallbackRecipe;
      }
      
      throw new Error('No se pudo cargar la receta');
    }
  },

  async createRecipe(recipeData: Partial<Recipe>, token: string): Promise<Recipe> {
    console.log('➕ Creando nueva receta...');
    const newRecipe: Recipe = {
      _id: Date.now().toString(),
      title: recipeData.title || 'Nueva Receta',
      description: recipeData.description || 'Descripción de la receta',
      ingredients: recipeData.ingredients || [],
      instructions: recipeData.instructions || [],
      preparationTime: recipeData.preparationTime || 30,
      difficulty: recipeData.difficulty || 'Media',
      category: recipeData.category || 'General',
      image: recipeData.image || 'https://via.placeholder.com/400x300?text=Receta+Personalizada',
      author: recipeData.author || { 
        id: 'user1', 
        username: 'Usuario', 
        email: 'usuario@ejemplo.com' 
      },
      ratings: [],
      createdAt: new Date().toISOString()
    };
    
    console.log('✅ Receta creada exitosamente');
    return newRecipe;
  },

  async updateRecipe(id: string, recipeData: Partial<Recipe>, token: string): Promise<Recipe> {
    console.log(`✏️ Actualizando receta: ${id}`);
    const updatedRecipe: Recipe = {
      _id: id,
      title: recipeData.title || 'Receta Actualizada',
      description: recipeData.description || '',
      ingredients: recipeData.ingredients || [],
      instructions: recipeData.instructions || [],
      preparationTime: recipeData.preparationTime || 30,
      difficulty: recipeData.difficulty || 'Media',
      category: recipeData.category || 'General',
      image: recipeData.image || 'https://via.placeholder.com/400x300?text=Receta+Actualizada',
      author: recipeData.author || { 
        id: 'user1', 
        username: 'Usuario', 
        email: 'usuario@ejemplo.com' 
      },
      ratings: [],
      createdAt: new Date().toISOString()
    };
    
    console.log('✅ Receta actualizada exitosamente');
    return updatedRecipe;
  },

  async deleteRecipe(id: string, token: string): Promise<void> {
    console.log(`🗑️ Eliminando receta: ${id}`);
    await new Promise(resolve => setTimeout(resolve, 500));
    console.log('✅ Receta eliminada exitosamente');
  },

  async getCuisines(): Promise<string[]> {
    return [
      'Mexicana', 'Italiana', 'China', 'India', 'Española',
      'Francesa', 'Japonesa', 'Tailandesa', 'Griega', 'Mediterránea',
      'Americana', 'Argentina', 'Peruana', 'Colombiana', 'Brasileña'
    ];
  },

  async getDiets(): Promise<string[]> {
    return [
      'Vegetariana', 'Vegana', 'Sin Gluten', 'Baja en Carbohidratos',
      'Sin Lactosa', 'Keto', 'Paleo', 'Baja en Grasa', 'Alta en Proteína'
    ];
  },

  async getCategories(): Promise<{name: string; image: string}[]> {
    return [
      { name: 'Carne de Res', image: 'https://www.themealdb.com/images/category/beef.png' },
      { name: 'Pollo', image: 'https://www.themealdb.com/images/category/chicken.png' },
      { name: 'Postre', image: 'https://www.themealdb.com/images/category/dessert.png' },
      { name: 'Pasta', image: 'https://www.themealdb.com/images/category/pasta.png' },
      { name: 'Mariscos', image: 'https://www.themealdb.com/images/category/seafood.png' },
      { name: 'Vegetariano', image: 'https://www.themealdb.com/images/category/vegetarian.png' },
      { name: 'Ensalada', image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=200&h=200&fit=crop' },
      { name: 'Sopa', image: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=200&h=200&fit=crop' }
    ];
  },

  // Búsqueda por ingredientes usando API Ninjas
  async searchRecipesByIngredients(ingredients: string[]): Promise<Recipe[]> {
    try {
      console.log(`🥕 Buscando recetas por ingredientes: ${ingredients.join(', ')}`);
      const recipes = await apiNinjasAPI.searchRecipesByIngredients(ingredients);
      
      // Guardar en caché
      recipes.forEach(recipe => ninjasRecipesCache.set(recipe._id, recipe));
      lastSearchResults = recipes;
      
      return recipes;
    } catch (error) {
      console.error('❌ Error buscando por ingredientes:', error);
      return [];
    }
  },

  // Limpiar caché (útil para testing)
  clearCache(): void {
    ninjasRecipesCache.clear();
    searchCache.clear();
    lastSearchResults = [];
    console.log('🧹 Caché de recetas limpiado');
  }
};

// Función para verificar la salud de todas las APIs
export const checkAPIsHealth = async (): Promise<{
  backend: boolean;
  apiNinjas: boolean;
  mealDB: boolean;
}> => {
  const results = {
    backend: false,
    apiNinjas: false,
    mealDB: false
  };

  try {
    const backendResponse = await axios.get(`${API_BASE_URL}/health`, { timeout: 5000 });
    results.backend = backendResponse.data.success === true;
  } catch (error) {
    console.error('❌ Backend no disponible');
  }

  try {
    results.apiNinjas = await apiNinjasAPI.testConnection();
  } catch (error) {
    console.error('❌ API Ninjas no disponible');
  }

  try {
    const mealDBResponse = await axios.get(`https://www.themealdb.com/api/json/v1/1/search.php?s=chicken`, { timeout: 5000 });
    results.mealDB = mealDBResponse.data.meals !== null;
  } catch (error) {
    console.error('❌ TheMealDB no disponible');
  }

  console.log('🏥 Estado de APIs:', results);
  return results;
};

// Exportar funciones auxiliares para testing
export const apiUtils = {
  getCacheStats: () => ({
    ninjasCacheSize: ninjasRecipesCache.size,
    searchCacheSize: searchCache.size,
    lastResultsCount: lastSearchResults.length
  }),
  clearAllCache: () => {
    ninjasRecipesCache.clear();
    searchCache.clear();
    lastSearchResults = [];
  },
  setDevelopmentMode: (mode: boolean) => {
    console.log(`🛠️  Modo desarrollo: ${mode}`);
  }
};