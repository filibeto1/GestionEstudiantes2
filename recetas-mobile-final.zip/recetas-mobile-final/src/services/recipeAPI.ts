import { apiRequest } from './api';

export interface Ingredient {
  name: string;
  quantity: string;
  unit: string;
}

export interface Instruction {
  step: number;
  description: string;
}

export interface Recipe {
  _id?: string;
  title: string;
  description: string;
  ingredients: Ingredient[];
  instructions: Instruction[];
  preparationTime: number;
  servings: number;
  difficulty: 'Fácil' | 'Medio' | 'Difícil';
  category: 'Desayuno' | 'Almuerzo' | 'Cena' | 'Postre' | 'Snack' | 'Bebida';
  image?: string;
  author: string;
  authorName: string;
  likes: string[];
  likesCount: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface PaginatedResponse {
  recipes: Recipe[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalRecipes: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
}

export const recipeAPI = {
  // Obtener recetas de la comunidad con paginación
  async getCommunityRecipes(page: number = 1, limit: number = 10): Promise<PaginatedResponse> {
    try {
      console.log(`🔍 Obteniendo recetas de la comunidad - Página: ${page}, Límite: ${limit}`);
      const data = await apiRequest(`/recipes/community?page=${page}&limit=${limit}`, {
        method: 'GET'
      });
      
      console.log(`📦 Recetas recibidas: ${data.recipes?.length || 0} de ${data.pagination?.totalRecipes || 0} totales`);
      
      const validatedRecipes = data.recipes.map((recipe: any) => ({
        ...recipe,
        title: recipe.title || 'Receta sin título',
        description: recipe.description || 'Descripción no disponible',
        ingredients: recipe.ingredients || [],
        instructions: recipe.instructions || [],
        category: recipe.category || 'General',
        difficulty: recipe.difficulty || 'Medio',
        preparationTime: recipe.preparationTime || 30,
        servings: recipe.servings || 1,
        likesCount: recipe.likesCount || 0,
        authorName: recipe.authorName || 'Anónimo'
      }));
      
      return {
        recipes: validatedRecipes,
        pagination: data.pagination
      };
    } catch (error) {
      console.error('❌ Error obteniendo recetas de la comunidad:', error);
      throw error;
    }
  },

  // Obtener mis recetas con paginación
  async getMyRecipes(page: number = 1, limit: number = 10): Promise<PaginatedResponse> {
    try {
      console.log(`🔍 Obteniendo mis recetas - Página: ${page}`);
      const data = await apiRequest(`/recipes/my-recipes?page=${page}&limit=${limit}`, {
        method: 'GET'
      });
      
      const validatedRecipes = data.recipes.map((recipe: any) => ({
        ...recipe,
        title: recipe.title || 'Receta sin título',
        description: recipe.description || 'Descripción no disponible',
        ingredients: recipe.ingredients || [],
        instructions: recipe.instructions || [],
        category: recipe.category || 'General',
        difficulty: recipe.difficulty || 'Medio',
        preparationTime: recipe.preparationTime || 30,
        servings: recipe.servings || 1,
        likesCount: recipe.likesCount || 0,
        authorName: recipe.authorName || 'Anónimo'
      }));
      
      return {
        recipes: validatedRecipes,
        pagination: data.pagination
      };
    } catch (error) {
      console.error('Error obteniendo mis recetas:', error);
      throw error;
    }
  },

  // Crear nueva receta
  async createRecipe(recipeData: Omit<Recipe, '_id' | 'author' | 'authorName' | 'likes' | 'likesCount' | 'createdAt' | 'updatedAt'>): Promise<Recipe> {
    try {
      console.log('🆕 Creando nueva receta...');
      const data = await apiRequest('/recipes', {
        method: 'POST',
        data: recipeData
      });
      console.log('✅ Receta creada exitosamente');
      return data.recipe;
    } catch (error) {
      console.error('Error creando receta:', error);
      throw error;
    }
  },

  // Obtener receta por ID
  async getRecipeById(id: string): Promise<Recipe> {
    try {
      console.log('🔍 Llamando a API para receta ID:', id);
      const data = await apiRequest(`/recipes/${id}`, {
        method: 'GET'
      });
      
      console.log('📦 Respuesta completa de API:', data);
      
      if (!data.recipe) {
        console.error('❌ No hay receta en la respuesta');
        throw new Error('Receta no encontrada en la respuesta');
      }
      
      console.log('✅ Receta recibida de API:', data.recipe.title);
      
      const recipe = data.recipe;
      const validatedRecipe = {
        ...recipe,
        title: recipe.title || 'Receta sin título',
        description: recipe.description || 'Descripción no disponible',
        ingredients: recipe.ingredients || [],
        instructions: recipe.instructions || [],
        category: recipe.category || 'General',
        difficulty: recipe.difficulty || 'Medio',
        preparationTime: recipe.preparationTime || 30,
        servings: recipe.servings || 1,
        likesCount: recipe.likesCount || 0,
        authorName: recipe.authorName || 'Anónimo'
      };
      
      console.log('✅ Receta validada:', validatedRecipe.title);
      return validatedRecipe;
    } catch (error) {
      console.error('❌ Error obteniendo receta de API:', error);
      throw error;
    }
  },

  // Like/Unlike receta
  async toggleLike(recipeId: string): Promise<{ likesCount: number; hasLiked: boolean }> {
    try {
      console.log('❤️ Procesando like para receta:', recipeId);
      const data = await apiRequest(`/recipes/${recipeId}/like`, {
        method: 'POST'
      });
      console.log('✅ Like procesado exitosamente');
      return data;
    } catch (error) {
      console.error('Error en like:', error);
      throw error;
    }
  },

  // Eliminar receta
  async deleteRecipe(recipeId: string): Promise<void> {
    try {
      console.log('🗑️ Eliminando receta:', recipeId);
      await apiRequest(`/recipes/${recipeId}`, {
        method: 'DELETE'
      });
      console.log('✅ Receta eliminada exitosamente');
    } catch (error) {
      console.error('Error eliminando receta:', error);
      throw error;
    }
  }
};