import { apiRequest } from './api';

export interface UserProfileData {
  personalInfo?: {
    age?: number;
    weight?: number;
    height?: number;
    gender?: 'male' | 'female' | 'other' | 'prefer_not_to_say';
    activityLevel?: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
    dailyCalorieGoal?: number;
  };
  healthInfo: {
    allergies: string[];
    dietaryRestrictions: string[];
    healthConditions: string[];
    healthGoals: string[];
  };
  preferences?: {
    favoriteCuisines?: string[];
    dislikedIngredients?: string[];
    cookingSkills?: 'beginner' | 'intermediate' | 'advanced';
  };
  bmi?: number;
  lastUpdated?: string;
  createdAt?: string;
}

export const userProfileAPI = {
  async getProfile(): Promise<UserProfileData> {
    try {
      console.log('📋 Obteniendo perfil desde userprofiles...');
      const data = await apiRequest('/user-profile', {
        method: 'GET'
      });

      if (!data.success) {
        throw new Error(data.message || 'Error obteniendo perfil');
      }

      console.log('✅ Perfil obtenido de userprofiles:', data.profile);
      return data.profile;
    } catch (error: any) {
      console.error('❌ Error obteniendo perfil:', error);
      // Si hay error, devolver perfil vacío en lugar de lanzar error
      return {
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      };
    }
  },

  async updateProfile(profileData: UserProfileData): Promise<UserProfileData> {
    try {
      console.log('💾 Guardando perfil completo...');
      const data = await apiRequest('/user-profile', {
        method: 'PUT',
        data: profileData
      });

      if (!data.success) {
        throw new Error(data.message || 'Error actualizando perfil');
      }

      console.log('✅ Perfil guardado exitosamente');
      return data.profile;
    } catch (error: any) {
      console.error('❌ Error actualizando perfil:', error);
      throw new Error(error.message);
    }
  },

  async updatePersonalInfo(personalInfo: UserProfileData['personalInfo']): Promise<UserProfileData> {
    try {
      console.log('💾 Guardando info personal...');
      const data = await apiRequest('/user-profile/personal', {
        method: 'PATCH',
        data: personalInfo
      });

      if (!data.success) {
        throw new Error(data.message || 'Error actualizando información personal');
      }

      console.log('✅ Info personal guardada exitosamente');
      return data.profile;
    } catch (error: any) {
      console.error('❌ Error actualizando info personal:', error);
      throw new Error(error.message);
    }
  },

  async updateHealthInfo(healthInfo: UserProfileData['healthInfo']): Promise<UserProfileData> {
    try {
      console.log('💾 Guardando info salud...');
      const data = await apiRequest('/user-profile/health', {
        method: 'PATCH',
        data: healthInfo
      });

      if (!data.success) {
        throw new Error(data.message || 'Error actualizando información de salud');
      }

      console.log('✅ Info salud guardada exitosamente');
      return data.profile;
    } catch (error: any) {
      console.error('❌ Error actualizando info salud:', error);
      throw new Error(error.message);
    }
  },

  async calculateBMI(): Promise<{ bmi: number; category: string }> {
    try {
      const data = await apiRequest('/user-profile/bmi', {
        method: 'GET'
      });

      if (!data.success) {
        throw new Error(data.message || 'Error calculando IMC');
      }

      return data;
    } catch (error: any) {
      console.error('❌ Error calculando IMC:', error);
      throw new Error(error.message);
    }
  },

  async getStats(): Promise<any> {
    try {
      const data = await apiRequest('/user-profile/stats', {
        method: 'GET'
      });

      return data.stats;
    } catch (error: any) {
      console.error('❌ Error obteniendo estadísticas:', error);
      throw new Error(error.message);
    }
  }
};