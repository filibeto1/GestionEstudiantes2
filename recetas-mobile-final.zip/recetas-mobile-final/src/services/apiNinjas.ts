// src/services/apiNinjas.ts - VERSIÓN CORREGIDA
import axios from 'axios';
import { Recipe, Ingredient, Instruction } from '../types';
import { translationService } from './translation';

const API_KEY = 'D5d0J/fPm3bUBaYH0lJ2OA==0Z7m4hpzKDPZ6UqB';
const BASE_URL = 'https://api.api-ninjas.com/v1/recipe';

// Función para limpiar y codificar parámetros de búsqueda
const cleanQuery = (query: string): string => {
  return query
    .trim()
    .toLowerCase()
    .replace(/[^\w\s]/gi, '')
    .replace(/\s+/g, ' ');
};

// Función para normalizar la dificultad
const normalizeDifficulty = (difficulty: string): "Fácil" | "Media" | "Difícil" => {
  const lowerDiff = difficulty.toLowerCase();
  if (lowerDiff.includes('fácil') || lowerDiff.includes('easy') || lowerDiff === 'fácil') {
    return 'Fácil';
  } else if (lowerDiff.includes('medio') || lowerDiff.includes('medium') || lowerDiff === 'media') {
    return 'Media';
  } else {
    return 'Difícil';
  }
};

// Mapear datos de API Ninjas a nuestro formato CON TRADUCCIÓN LOCAL
const mapApiNinjasToRecipe = async (recipe: any, index: number): Promise<Recipe> => {
  // Crear un ID único y persistente
  const generatePersistentId = (title: string): string => {
    const cleanTitle = title.toLowerCase().replace(/[^a-z0-9]/g, '');
    const timestamp = Date.now().toString(36);
    return `ninjas-${cleanTitle.substring(0, 8)}-${timestamp}-${index}`;
  };

  // Parsear ingredientes de forma RÁPIDA
  const ingredients: Ingredient[] = [];
  if (recipe.ingredients) {
    const ingredientLines = recipe.ingredients.split('|');
    
    for (let i = 0; i < Math.min(ingredientLines.length, 12); i++) {
      const line = ingredientLines[i].trim();
      if (line) {
        // Parseo rápido y simple
        const words = line.split(' ');
        let quantity = '';
        let name = line;
        
        // Detectar cantidades al inicio
        if (words.length > 1 && /^[\d\/\.]/.test(words[0])) {
          quantity = words[0];
          name = words.slice(1).join(' ');
        }
        
        // TRADUCCIÓN LOCAL INMEDIATA para ingredientes
        const translatedName = translationService.getCurrentLanguage() === 'es' 
          ? translationService.translateLocally(name)
          : name;
        
        ingredients.push({
          name: translatedName,
          quantity: quantity,
          unit: ''
        });
      }
    }
  }

  // Parsear instrucciones de forma RÁPIDA
  const instructions: Instruction[] = [];
  if (recipe.instructions) {
    // Dividir por oraciones simples
    const sentences = recipe.instructions.split(/\.\s+(?=[A-Z])|\.$/).filter((s: string) => s.trim());
    
    for (let i = 0; i < Math.min(sentences.length, 8); i++) {
      let step = sentences[i].trim();
      if (step) {
        // Limpiar números de paso si existen
        step = step.replace(/^\d+\.\s*/, '');
        
        // TRADUCCIÓN LOCAL básica para instrucciones
        const translatedStep = translationService.getCurrentLanguage() === 'es'
          ? translationService.translateLocally(step)
          : step;
        
        instructions.push({
          step: i + 1,
          description: translatedStep
        });
      }
    }
  }

  // Si no hay instrucciones, crear una básica
  if (instructions.length === 0) {
    const defaultInstruction = translationService.getCurrentLanguage() === 'es'
      ? 'Sigue las instrucciones de la receta original.'
      : 'Follow the original recipe instructions.';
    
    instructions.push({
      step: 1,
      description: defaultInstruction
    });
  }

  // Determinar dificultad y tiempo
  const prepTime = parseInt(recipe.prep_time_minutes) || 30;
  const difficulty = normalizeDifficulty(recipe.difficulty || (prepTime <= 20 ? 'Fácil' : prepTime <= 45 ? 'Media' : 'Difícil'));
  const servings = recipe.servings || '4';

  // TRADUCCIÓN LOCAL INMEDIATA para título
  let title = recipe.title || 'Receta sin título';
  if (translationService.getCurrentLanguage() === 'es') {
    title = translationService.translateLocally(title);
  }

  const description = translationService.getCurrentLanguage() === 'es'
    ? `Deliciosa receta de ${title}. ${servings ? `Para ${servings} personas.` : 'Perfecta para cualquier ocasión.'}`
    : `Delicious recipe for ${title}. ${servings ? `For ${servings} people.` : 'Perfect for any occasion.'}`;

  return {
    _id: generatePersistentId(recipe.title),
    title,
    description,
    ingredients,
    instructions,
    preparationTime: prepTime,
    difficulty: difficulty,
    category: translationService.getCurrentLanguage() === 'es' ? 'General' : 'General',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop',
    author: {
      id: 'apininjas',
      username: 'API Ninjas',
      email: 'info@apininjas.com'
    },
    ratings: [],
    createdAt: new Date().toISOString()
  };
};

export const apiNinjasAPI = {
  // Buscar recetas por término - CON TRADUCCIÓN LOCAL
  async searchRecipes(query: string): Promise<Recipe[]> {
    try {
      const cleanedQuery = cleanQuery(query);
      console.log(`🔍 Buscando recetas en API Ninjas: "${cleanedQuery}"`);
      
      const response = await axios.get(BASE_URL, {
        params: { query: cleanedQuery },
        headers: {
          'X-Api-Key': API_KEY,
          'Content-Type': 'application/json'
        },
        timeout: 8000
      });

      console.log('📊 Respuesta de API Ninjas:', response.data?.length || 0, 'recetas');

      if (response.data && Array.isArray(response.data)) {
        // Procesar solo las primeras 4 recetas para mayor velocidad
        const limitedRecipes = response.data.slice(0, 4);
        const recipesPromises = limitedRecipes.map(async (recipe: any, index: number) => 
          await mapApiNinjasToRecipe(recipe, index)
        );
        
        const recipes = await Promise.all(recipesPromises);
        console.log(`✅ ${recipes.length} recetas procesadas con traducción local`);
        return recipes;
      }
      
      console.log('❌ No se encontraron recetas en API Ninjas');
      return [];
    } catch (error: any) {
      console.error('❌ Error buscando recetas en API Ninjas:', error.response?.data || error.message);
      return [];
    }
  },

  // Buscar recetas por ingredientes - CON TRADUCCIÓN LOCAL
  async searchRecipesByIngredients(ingredients: string[]): Promise<Recipe[]> {
    try {
      const mainIngredient = ingredients[0];
      const cleanedIngredient = cleanQuery(mainIngredient);
      
      console.log(`🥕 Buscando recetas por ingrediente principal: "${cleanedIngredient}"`);
      
      const response = await axios.get(BASE_URL, {
        params: { query: cleanedIngredient },
        headers: {
          'X-Api-Key': API_KEY,
          'Content-Type': 'application/json'
        },
        timeout: 8000
      });

      console.log('📊 Respuesta por ingredientes:', response.data?.length || 0, 'recetas');

      if (response.data && Array.isArray(response.data)) {
        const limitedRecipes = response.data.slice(0, 4);
        const recipesPromises = limitedRecipes.map(async (recipe: any, index: number) => 
          await mapApiNinjasToRecipe(recipe, index)
        );
        
        const recipes = await Promise.all(recipesPromises);
        console.log(`✅ ${recipes.length} recetas con ${cleanedIngredient} (traducidas)`);
        return recipes;
      }
      
      return [];
    } catch (error: any) {
      console.error('❌ Error buscando recetas por ingredientes:', error.response?.data || error.message);
      return [];
    }
  },

  // Obtener recetas por categoría - CON TRADUCCIÓN LOCAL
  async getRecipesByCategory(category: string): Promise<Recipe[]> {
    try {
      const categoryMap: { [key: string]: string } = {
        'Carne de Res': 'beef',
        'Pollo': 'chicken',
        'Postre': 'dessert',
        'Pasta': 'pasta',
        'Mariscos': 'seafood',
        'Vegetariano': 'vegetarian',
        'Desayuno': 'breakfast',
        'Ensalada': 'salad',
        'Sopa': 'soup',
        'General': 'easy'
      };

      const searchTerm = categoryMap[category] || 'easy';
      const cleanedQuery = cleanQuery(searchTerm);
      
      console.log(`📁 Buscando recetas de categoría: ${category} -> "${cleanedQuery}"`);
      
      const response = await axios.get(BASE_URL, {
        params: { query: cleanedQuery },
        headers: {
          'X-Api-Key': API_KEY,
          'Content-Type': 'application/json'
        },
        timeout: 8000
      });

      console.log('📊 Respuesta por categoría:', response.data?.length || 0, 'recetas');

      if (response.data && Array.isArray(response.data)) {
        const limitedRecipes = response.data.slice(0, 4);
        const recipesPromises = limitedRecipes.map(async (recipe: any, index: number) => 
          await mapApiNinjasToRecipe(recipe, index)
        );
        
        const recipes = await Promise.all(recipesPromises);
        console.log(`✅ ${recipes.length} recetas de ${category} (traducidas)`);
        return recipes;
      }
      
      return [];
    } catch (error: any) {
      console.error('❌ Error obteniendo recetas por categoría:', error.response?.data || error.message);
      return [];
    }
  },

  // Obtener recetas populares - CON TRADUCCIÓN LOCAL
  async getPopularRecipes(): Promise<Recipe[]> {
    try {
      console.log('🔥 Obteniendo recetas populares de API Ninjas');
      
      const response = await axios.get(BASE_URL, {
        params: { query: 'chicken' },
        headers: {
          'X-Api-Key': API_KEY,
          'Content-Type': 'application/json'
        },
        timeout: 8000
      });

      console.log('📊 Recetas populares:', response.data?.length || 0, 'recetas');

      if (response.data && Array.isArray(response.data)) {
        const limitedRecipes = response.data.slice(0, 4);
        const recipesPromises = limitedRecipes.map(async (recipe: any, index: number) => 
          await mapApiNinjasToRecipe(recipe, index)
        );
        
        const recipes = await Promise.all(recipesPromises);
        console.log(`✅ ${recipes.length} recetas populares cargadas (traducidas)`);
        return recipes;
      }
      
      console.log('❌ No se obtuvieron recetas populares');
      return [];
    } catch (error: any) {
      console.error('❌ Error obteniendo recetas populares:', error.response?.data || error.message);
      return [];
    }
  },

  // Verificar que la API funciona
  async testConnection(): Promise<boolean> {
    try {
      console.log('🧪 Probando conexión con API Ninjas...');
      
      const response = await axios.get(BASE_URL, {
        params: { query: 'chicken' },
        headers: {
          'X-Api-Key': API_KEY,
          'Content-Type': 'application/json'
        },
        timeout: 5000
      });
      
      console.log('✅ Conexión con API Ninjas exitosa');
      return response.status === 200;
    } catch (error: any) {
      console.error('❌ Error conectando con API Ninjas:', error.response?.data || error.message);
      return false;
    }
  }
};