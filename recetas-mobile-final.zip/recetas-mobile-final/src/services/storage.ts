// src/services/storage.ts - VERSIÓN COMPLETA CORREGIDA
import * as SecureStore from 'expo-secure-store';
import { User, UserProfileData } from '../types';

// Perfil por defecto - CORREGIDO para coincidir con UserProfileData
const defaultProfile: UserProfileData = {
  personalInfo: {},
  healthInfo: {
    allergies: [],
    dietaryRestrictions: [],
    healthConditions: [],
    healthGoals: []
  },
  preferences: {
    favoriteCuisines: [],
    dislikedIngredients: [],
    cookingSkills: 'beginner'
  }
};

export const storage = {
  async saveToken(token: string): Promise<void> {
    try {
      await SecureStore.setItemAsync('auth_token', token);
      console.log('✅ Token guardado exitosamente');
    } catch (error) {
      console.error('❌ Error saving token:', error);
      throw new Error('No se pudo guardar el token de autenticación');
    }
  },

  async getToken(): Promise<string | null> {
    try {
      const token = await SecureStore.getItemAsync('auth_token');
      console.log('🔍 Token recuperado:', token ? '✅ Existe' : '❌ No existe');
      return token;
    } catch (error) {
      console.error('❌ Error getting token:', error);
      return null;
    }
  },

  async removeToken(): Promise<void> {
    try {
      await SecureStore.deleteItemAsync('auth_token');
      console.log('✅ Token eliminado exitosamente');
    } catch (error) {
      console.error('❌ Error removing token:', error);
      throw new Error('No se pudo eliminar el token de autenticación');
    }
  },

  async saveUser(user: User): Promise<void> {
    try {
      // Asegurar que el usuario tenga la estructura correcta
      const userToSave: User = {
        ...user,
        profile: user.profile || defaultProfile
      };
      
      await SecureStore.setItemAsync('user_data', JSON.stringify(userToSave));
      console.log('✅ Usuario guardado exitosamente:', {
        id: userToSave.id,
        username: userToSave.username,
        hasProfile: !!userToSave.profile
      });
    } catch (error) {
      console.error('❌ Error saving user:', error);
      throw new Error('No se pudo guardar la información del usuario');
    }
  },

  async getUser(): Promise<User | null> {
    try {
      const userData = await SecureStore.getItemAsync('user_data');
      
      if (userData) {
        const user = JSON.parse(userData);
        
        // Asegurar compatibilidad con versiones anteriores
        const userWithProfile: User = {
          ...user,
          profile: user.profile || defaultProfile
        };
        
        console.log('✅ Usuario recuperado:', {
          id: userWithProfile.id,
          username: userWithProfile.username,
          hasProfile: !!userWithProfile.profile
        });
        
        return userWithProfile;
      }
      
      console.log('ℹ️ No hay usuario guardado');
      return null;
    } catch (error) {
      console.error('❌ Error getting user:', error);
      return null;
    }
  },

  async removeUser(): Promise<void> {
    try {
      await SecureStore.deleteItemAsync('user_data');
      console.log('✅ Usuario eliminado exitosamente');
    } catch (error) {
      console.error('❌ Error removing user:', error);
      throw new Error('No se pudo eliminar la información del usuario');
    }
  },

  // ✅ AÑADIDO: Función clearAuth para compatibilidad
  async clearAuth(): Promise<void> {
    try {
      console.log('🧹 Iniciando limpieza de datos de autenticación...');
      
      await Promise.all([
        this.removeToken(),
        this.removeUser()
      ]);
      
      console.log('✅ Todos los datos de autenticación eliminados exitosamente');
    } catch (error) {
      console.error('❌ Error clearing auth data:', error);
      throw new Error('No se pudieron limpiar los datos de autenticación');
    }
  },

  async clearAuthData(): Promise<void> {
    return this.clearAuth(); // Alias para compatibilidad
  },

  async saveProfile(profile: UserProfileData): Promise<void> {
    try {
      const user = await this.getUser();
      
      if (user) {
        const updatedUser: User = {
          ...user,
          profile: profile
        };
        
        await this.saveUser(updatedUser);
        console.log('✅ Perfil guardado exitosamente');
      } else {
        throw new Error('No hay usuario logueado para guardar el perfil');
      }
    } catch (error) {
      console.error('❌ Error saving profile:', error);
      throw new Error('No se pudo guardar el perfil');
    }
  },

  async getProfile(): Promise<UserProfileData | null> {
    try {
      const user = await this.getUser();
      
      if (user && user.profile) {
        console.log('✅ Perfil recuperado exitosamente');
        return user.profile;
      }
      
      console.log('ℹ️ No hay perfil guardado');
      return null;
    } catch (error) {
      console.error('❌ Error getting profile:', error);
      return null;
    }
  },

  // Función para verificar si existe autenticación
  async hasAuthData(): Promise<boolean> {
    try {
      const [token, user] = await Promise.all([
        this.getToken(),
        this.getUser()
      ]);
      
      const hasAuth = !!(token && user);
      console.log('🔍 Verificando autenticación:', {
        hasToken: !!token,
        hasUser: !!user,
        hasAuth
      });
      
      return hasAuth;
    } catch (error) {
      console.error('❌ Error checking auth data:', error);
      return false;
    }
  },

  // Función para obtener todos los datos de autenticación
  async getAuthData(): Promise<{ token: string | null; user: User | null }> {
    try {
      const [token, user] = await Promise.all([
        this.getToken(),
        this.getUser()
      ]);
      
      return { token, user };
    } catch (error) {
      console.error('❌ Error getting auth data:', error);
      return { token: null, user: null };
    }
  },

  // Función para limpiar caché específica (útil para debugging)
  async clearAllStorage(): Promise<void> {
    try {
      console.log('🧹🧹🧹 LIMPIANDO TODO EL ALMACENAMIENTO...');
      
      // Obtener todas las keys (esto puede variar según la implementación de SecureStore)
      const keys = ['auth_token', 'user_data'];
      
      await Promise.all(
        keys.map(key => SecureStore.deleteItemAsync(key))
      );
      
      console.log('✅ Todo el almacenamiento limpiado exitosamente');
    } catch (error) {
      console.error('❌ Error clearing all storage:', error);
      throw new Error('No se pudo limpiar el almacenamiento');
    }
  },

  // Función clear para compatibilidad con el código existente
  async clear(): Promise<void> {
    try {
      console.log('🧹 Limpiando storage (función clear)...');
      await this.clearAuth();
      console.log('✅ Storage limpiado exitosamente usando clear()');
    } catch (error) {
      console.error('❌ Error en clear():', error);
      throw error;
    }
  },

  // Función clearAll para compatibilidad
  async clearAll(): Promise<void> {
    try {
      console.log('🧹 Limpiando todo el storage...');
      await this.clearAllStorage();
      console.log('✅ Todo el storage limpiado exitosamente');
    } catch (error) {
      console.error('❌ Error en clearAll():', error);
      throw error;
    }
  },

  // Función para actualizar solo una parte del perfil
  async updateProfilePartial(updates: Partial<UserProfileData>): Promise<void> {
    try {
      const user = await this.getUser();
      
      if (user) {
        const currentProfile = user.profile || defaultProfile;
        const updatedProfile: UserProfileData = {
          personalInfo: { ...currentProfile.personalInfo, ...updates.personalInfo },
          healthInfo: {
            allergies: updates.healthInfo?.allergies || currentProfile.healthInfo.allergies,
            dietaryRestrictions: updates.healthInfo?.dietaryRestrictions || currentProfile.healthInfo.dietaryRestrictions,
            healthConditions: updates.healthInfo?.healthConditions || currentProfile.healthInfo.healthConditions,
            healthGoals: updates.healthInfo?.healthGoals || currentProfile.healthInfo.healthGoals
          },
          preferences: { ...currentProfile.preferences, ...updates.preferences }
        };
        
        const updatedUser: User = {
          ...user,
          profile: updatedProfile
        };
        
        await this.saveUser(updatedUser);
        console.log('✅ Perfil parcial actualizado exitosamente');
      } else {
        throw new Error('No hay usuario logueado para actualizar el perfil');
      }
    } catch (error) {
      console.error('❌ Error updating profile partial:', error);
      throw new Error('No se pudo actualizar el perfil');
    }
  },

  // Función para obtener estadísticas del storage
  async getStorageStats(): Promise<{
    hasToken: boolean;
    hasUser: boolean;
    hasProfile: boolean;
    userInfo: { id?: string; username?: string } | null;
  }> {
    try {
      const [token, user] = await Promise.all([
        this.getToken(),
        this.getUser()
      ]);
      
      return {
        hasToken: !!token,
        hasUser: !!user,
        hasProfile: !!(user && user.profile),
        userInfo: user ? { id: user.id, username: user.username } : null
      };
    } catch (error) {
      console.error('❌ Error getting storage stats:', error);
      return {
        hasToken: false,
        hasUser: false,
        hasProfile: false,
        userInfo: null
      };
    }
  }
};

// Exportar el perfil por defecto por si se necesita
export { defaultProfile };