import axios from 'axios';
import { Recipe, Ingredient, Instruction, User } from '../types';

const API_KEY = '9ca1ceb97e4d4f2193961c49d12e6d68';
const BASE_URL = 'https://api.spoonacular.com';

// Mapear datos de Spoonacular a nuestro formato en español
const mapSpoonacularToRecipe = (recipe: any): Recipe => {
  const ingredients: Ingredient[] = recipe.extendedIngredients?.map((ing: any) => ({
    name: traducirIngrediente(ing.nameClean || ing.originalName || ing.name),
    quantity: ing.amount?.toString() || '',
    unit: traducirUnidad(ing.unit || '')
  })) || [];

  const instructions: Instruction[] = recipe.analyzedInstructions?.[0]?.steps?.map((step: any) => ({
    step: step.number,
    description: step.step // Ya viene en español por el parámetro language=es
  })) || [];

  // Si no hay instrucciones analizadas, usar summary
  if (instructions.length === 0 && recipe.summary) {
    instructions.push({
      step: 1,
      description: recipe.summary.replace(/<[^>]*>/g, '').substring(0, 300) + '...'
    });
  }

  return {
    _id: recipe.id.toString(),
    title: recipe.title,
    description: recipe.summary ? 
      recipe.summary.replace(/<[^>]*>/g, '').substring(0, 200) + '...' : 
      'Receta deliciosa y fácil de preparar',
    ingredients,
    instructions,
    preparationTime: recipe.readyInMinutes || 30,
    difficulty: getDifficultyLevel(recipe.readyInMinutes),
    category: getCategoryInSpanish(recipe.dishTypes?.[0] || recipe.cuisines?.[0] || 'General'),
    image: recipe.image,
    author: {
      id: 'spoonacular',
      username: 'Spoonacular',
      email: 'info@spoonacular.com'
    },
    ratings: [],
    createdAt: new Date().toISOString()
  };
};

// Traductor de ingredientes comunes
const traducirIngrediente = (ingrediente: string): string => {
  const traducciones: { [key: string]: string } = {
    'salt': 'sal',
    'pepper': 'pimienta',
    'sugar': 'azúcar',
    'flour': 'harina',
    'butter': 'mantequilla',
    'oil': 'aceite',
    'garlic': 'ajo',
    'onion': 'cebolla',
    'tomato': 'tomate',
    'egg': 'huevo',
    'milk': 'leche',
    'water': 'agua',
    'rice': 'arroz',
    'chicken': 'pollo',
    'beef': 'carne de res',
    'pork': 'cerdo',
    'fish': 'pescado',
    'cheese': 'queso',
    'bread': 'pan',
    'lemon': 'limón',
    'lime': 'lima',
    'carrot': 'zanahoria',
    'potato': 'papa',
    'bell pepper': 'pimiento',
    'cilantro': 'cilantro',
    'parsley': 'perejil',
    'basil': 'albahaca',
    'oregano': 'orégano'
  };

  const ingredienteLower = ingrediente.toLowerCase();
  return traducciones[ingredienteLower] || ingrediente;
};

// Traductor de unidades de medida
const traducirUnidad = (unidad: string): string => {
  const traducciones: { [key: string]: string } = {
    'tablespoon': 'cucharada',
    'tablespoons': 'cucharadas',
    'teaspoon': 'cucharadita',
    'teaspoons': 'cucharaditas',
    'cup': 'taza',
    'cups': 'tazas',
    'ounce': 'onza',
    'ounces': 'onzas',
    'pound': 'libra',
    'pounds': 'libras',
    'gram': 'gramo',
    'grams': 'gramos',
    'kilogram': 'kilogramo',
    'kilograms': 'kilogramos',
    'milliliter': 'mililitro',
    'milliliters': 'mililitros',
    'liter': 'litro',
    'liters': 'litros',
    'clove': 'diente',
    'cloves': 'dientes',
    'slice': 'rebanada',
    'slices': 'rebanadas',
    'piece': 'pieza',
    'pieces': 'piezas'
  };

  const unidadLower = unidad.toLowerCase();
  return traducciones[unidadLower] || unidad;
};

const getDifficultyLevel = (prepTime: number): 'Fácil' | 'Media' | 'Difícil' => {
  if (prepTime <= 20) return 'Fácil';
  if (prepTime <= 45) return 'Media';
  return 'Difícil';
};

// Traducir categorías al español
const getCategoryInSpanish = (category: string): string => {
  const categoryMap: { [key: string]: string } = {
    'main course': 'Plato Principal',
    'side dish': 'Acompañamiento',
    'dessert': 'Postre',
    'appetizer': 'Aperitivo',
    'salad': 'Ensalada',
    'bread': 'Pan',
    'breakfast': 'Desayuno',
    'soup': 'Sopa',
    'beverage': 'Bebida',
    'sauce': 'Salsa',
    'marinade': 'Adobo',
    'fingerfood': 'Bocadillo',
    'snack': 'Merienda',
    'drink': 'Bebida',
    'italian': 'Italiana',
    'mexican': 'Mexicana',
    'chinese': 'China',
    'indian': 'India',
    'american': 'Americana',
    'mediterranean': 'Mediterránea',
    'french': 'Francesa',
    'asian': 'Asiática',
    'spanish': 'Española',
    'thai': 'Tailandesa',
    'japanese': 'Japonesa',
    'greek': 'Griega'
  };
  
  return categoryMap[category.toLowerCase()] || category;
};

export const spoonacularAPI = {
  // Buscar recetas EN ESPAÑOL
  async searchRecipes(searchTerm: string, cuisine?: string, diet?: string): Promise<Recipe[]> {
    try {
      const params: any = {
        apiKey: API_KEY,
        query: searchTerm,
        number: 20,
        addRecipeInformation: true,
        fillIngredients: true,
        language: 'es', // ✅ Español forzado
        instructionsRequired: true
      };

      if (cuisine) params.cuisine = cuisine;
      if (diet) params.diet = diet;

      console.log('🔍 Buscando recetas en español...');
      
      const response = await axios.get(`${BASE_URL}/recipes/complexSearch`, { params });
      
      if (response.data.results) {
        const recipes = response.data.results.map(mapSpoonacularToRecipe);
        console.log(`✅ Encontradas ${recipes.length} recetas en español`);
        return recipes;
      }
      return [];
    } catch (error) {
      console.error('❌ Error buscando recetas:', error);
      return [];
    }
  },

  // Obtener recetas por categoría EN ESPAÑOL
  async getRecipesByCategory(category: string): Promise<Recipe[]> {
    try {
      const response = await axios.get(`${BASE_URL}/recipes/complexSearch`, {
        params: {
          apiKey: API_KEY,
          type: category.toLowerCase(),
          number: 12,
          addRecipeInformation: true,
          fillIngredients: true,
          language: 'es', // ✅ Español forzado
          instructionsRequired: true
        }
      });

      if (response.data.results) {
        const recipes = response.data.results.map(mapSpoonacularToRecipe);
        console.log(`✅ ${recipes.length} recetas de ${category} en español`);
        return recipes;
      }
      return [];
    } catch (error) {
      console.error('❌ Error obteniendo recetas por categoría:', error);
      return [];
    }
  },

  // Obtener receta por ID EN ESPAÑOL
  async getRecipeById(id: string): Promise<Recipe | null> {
    try {
      const response = await axios.get(`${BASE_URL}/recipes/${id}/information`, {
        params: {
          apiKey: API_KEY,
          includeNutrition: false,
          language: 'es' // ✅ Español forzado
        }
      });

      console.log('📄 Receta obtenida en español');
      return mapSpoonacularToRecipe(response.data);
    } catch (error) {
      console.error('❌ Error obteniendo receta por ID:', error);
      return null;
    }
  },

  // Obtener recetas aleatorias (populares) EN ESPAÑOL
  async getPopularRecipes(): Promise<Recipe[]> {
    try {
      const response = await axios.get(`${BASE_URL}/recipes/random`, {
        params: {
          apiKey: API_KEY,
          number: 8,
          language: 'es' // ✅ Español forzado
        }
      });

      if (response.data.recipes) {
        const recipes = response.data.recipes.map(mapSpoonacularToRecipe);
        console.log(`✅ ${recipes.length} recetas populares en español`);
        return recipes;
      }
      return [];
    } catch (error) {
      console.error('❌ Error obteniendo recetas populares:', error);
      return [];
    }
  },

  // Obtener cocinas disponibles EN ESPAÑOL
  async getCuisines(): Promise<string[]> {
    try {
      return [
        'Africana', 'Americana', 'Británica', 'Cajún', 'Caribeña', 
        'China', 'Europea Oriental', 'Europea', 'Francesa', 'Alemana',
        'Griega', 'India', 'Irlandesa', 'Italiana', 'Japonesa', 
        'Judía', 'Coreana', 'Latinoamericana', 'Mediterránea', 'Mexicana',
        'Medio Oriente', 'Nórdica', 'Sureña', 'Española', 'Tailandesa', 'Vietnamita'
      ];
    } catch (error) {
      console.error('❌ Error obteniendo cocinas:', error);
      return ['Italiana', 'Mexicana', 'China', 'India', 'Americana', 'Mediterránea'];
    }
  },

  // Obtener tipos de dieta EN ESPAÑOL
  async getDiets(): Promise<string[]> {
    return [
      'Sin Gluten', 
      'Cetogénica', 
      'Vegetariana', 
      'Lacto-Vegetariana', 
      'Ovo-Vegetariana',
      'Vegana', 
      'Pescetariana', 
      'Paleo', 
      'Primal', 
      'Baja en FODMAP',
      'Whole30'
    ];
  },

  // Obtener recetas por ingredientes EN ESPAÑOL
  async getRecipesByIngredients(ingredients: string[]): Promise<Recipe[]> {
    try {
      const response = await axios.get(`${BASE_URL}/recipes/findByIngredients`, {
        params: {
          apiKey: API_KEY,
          ingredients: ingredients.join(','),
          number: 10,
          ranking: 2,
          ignorePantry: true,
          language: 'es' // ✅ Español forzado
        }
      });

      // Obtener información completa de cada receta
      const detailedRecipes = await Promise.all(
        response.data.map(async (recipe: any) => {
          try {
            const detailedRecipe = await this.getRecipeById(recipe.id.toString());
            return detailedRecipe;
          } catch (error) {
            console.error('Error obteniendo receta detallada:', error);
            return mapSpoonacularToRecipe(recipe);
          }
        })
      );

      const filteredRecipes = detailedRecipes.filter(recipe => recipe !== null) as Recipe[];
      console.log(`✅ ${filteredRecipes.length} recetas por ingredientes en español`);
      return filteredRecipes;
    } catch (error) {
      console.error('❌ Error obteniendo recetas por ingredientes:', error);
      return [];
    }
  }
};