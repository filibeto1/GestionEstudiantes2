// src/context/AuthContext.tsx - VERSIÓN CON ROLES
import React, { createContext, useState, useContext, useEffect } from 'react';
import { authAPI } from '../services/api';
import { userProfileAPI } from '../services/userProfileAPI';
import { storage } from '../services/storage';
import { User, UserProfileData } from '../types';

interface AuthContextType {
  user: User | null;
  userProfile: UserProfileData | null;
  isAuthenticated: boolean;
  isAdmin: boolean; // ✅ AÑADIDO
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  updatePersonalInfo: (personalInfo: UserProfileData['personalInfo']) => Promise<void>;
  updateHealthInfo: (healthInfo: UserProfileData['healthInfo']) => Promise<void>;
  refreshUserProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfileData | null>(null);
  const [loading, setLoading] = useState(true);

  // ✅ CALCULAR SI ES ADMIN
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      setLoading(true);
      const storedUser = await storage.getUser();
      const token = await storage.getToken();
      
      if (storedUser && token) {
        console.log('👤 Usuario cargado desde storage:', storedUser.username, 'Rol:', storedUser.role);
        setUser(storedUser);
        
        try {
          console.log('🔄 Cargando perfil desde la base de datos...');
          const profileData = await userProfileAPI.getProfile();
          setUserProfile(profileData);
          console.log('✅ Perfil cargado exitosamente');
        } catch (error) {
          console.error('❌ Error cargando perfil:', error);
          setUserProfile({
            personalInfo: {},
            healthInfo: {
              allergies: [],
              dietaryRestrictions: [],
              healthConditions: [],
              healthGoals: []
            },
            preferences: {
              favoriteCuisines: [],
              dislikedIngredients: [],
              cookingSkills: 'beginner'
            }
          });
        }
      } else {
        console.log('🔐 No hay usuario autenticado en storage');
        setUser(null);
        setUserProfile(null);
      }
    } catch (error) {
      console.error('❌ Error cargando datos del usuario:', error);
      setUser(null);
      setUserProfile(null);
    } finally {
      setLoading(false);
    }
  };

  const refreshUserProfile = async (): Promise<void> => {
    try {
      console.log('🔄 Actualizando perfil desde la base de datos...');
      const profileData = await userProfileAPI.getProfile();
      setUserProfile(profileData);
      console.log('✅ Perfil actualizado exitosamente');
    } catch (error) {
      console.error('❌ Error actualizando perfil:', error);
      throw error;
    }
  };

  const login = async (email: string, password: string): Promise<void> => {
    try {
      setLoading(true);
      console.log('🔐 Iniciando sesión...');
      
      const response = await authAPI.login(email, password);
      
      await storage.saveToken(response.token);
      await storage.saveUser(response.user);
      
      setUser(response.user);
      console.log('✅ Sesión iniciada exitosamente. Rol:', response.user.role);
      
      try {
        await refreshUserProfile();
      } catch (profileError) {
        console.warn('⚠️ No se pudo cargar perfil completo, inicializando vacío:', profileError);
        setUserProfile({
          personalInfo: {},
          healthInfo: {
            allergies: [],
            dietaryRestrictions: [],
            healthConditions: [],
            healthGoals: []
          },
          preferences: {
            favoriteCuisines: [],
            dislikedIngredients: [],
            cookingSkills: 'beginner'
          }
        });
      }
    } catch (error) {
      console.error('❌ Error en login:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const register = async (username: string, email: string, password: string): Promise<void> => {
    try {
      setLoading(true);
      console.log('📝 Registrando usuario...');
      
      const response = await authAPI.register(username, email, password);
      
      await storage.saveToken(response.token);
      await storage.saveUser(response.user);
      
      setUser(response.user);
      
      setUserProfile({
        personalInfo: {},
        healthInfo: {
          allergies: [],
          dietaryRestrictions: [],
          healthConditions: [],
          healthGoals: []
        },
        preferences: {
          favoriteCuisines: [],
          dislikedIngredients: [],
          cookingSkills: 'beginner'
        }
      });
      
      console.log('✅ Usuario registrado exitosamente. Rol:', response.user.role);
    } catch (error) {
      console.error('❌ Error en registro:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setLoading(true);
      console.log('🚪 Cerrando sesión...');
      
      await storage.removeToken();
      await storage.removeUser();
      setUser(null);
      setUserProfile(null);
      
      console.log('✅ Sesión cerrada exitosamente');
    } catch (error) {
      console.error('❌ Error cerrando sesión:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const updatePersonalInfo = async (personalInfo: UserProfileData['personalInfo']): Promise<void> => {
    try {
      console.log('💾 Actualizando información personal...');
      
      const updatedProfile = await userProfileAPI.updatePersonalInfo(personalInfo);
      setUserProfile(updatedProfile);
      
      console.log('✅ Información personal guardada en base de datos');
    } catch (error) {
      console.error('❌ Error actualizando información personal:', error);
      throw error;
    }
  };

  const updateHealthInfo = async (healthInfo: UserProfileData['healthInfo']): Promise<void> => {
    try {
      console.log('💾 Actualizando información de salud...');
      
      const updatedProfile = await userProfileAPI.updateHealthInfo(healthInfo);
      setUserProfile(updatedProfile);
      
      console.log('✅ Información de salud guardada en base de datos');
    } catch (error) {
      console.error('❌ Error actualizando información de salud:', error);
      throw error;
    }
  };

  const value: AuthContextType = {
    user,
    userProfile,
    isAuthenticated: !!user,
    isAdmin, // ✅ AÑADIDO
    loading,
    login,
    register,
    logout,
    updatePersonalInfo,
    updateHealthInfo,
    refreshUserProfile
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth debe ser usado dentro de un AuthProvider');
  }
  return context;
};