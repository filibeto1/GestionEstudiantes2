import React, { useState, useEffect } from 'react';
import { 
  View, Text, FlatList, TextInput, StyleSheet, ActivityIndicator, 
  TouchableOpacity, Modal, ScrollView, Alert 
} from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { Recipe } from '../types';
import { recipesAPI } from '../services/api';
import { mealDbAPI } from '../services/mealDbApi';
import { RecipeCard } from '../components/RecipeCard';
import { RecipesScreenNavigationProp, RootStackParamList } from '../types/navigation';

type RecipesScreenRouteProp = RouteProp<RootStackParamList, 'Recipes'>;

export const RecipesScreen: React.FC = () => {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [cuisines, setCuisines] = useState<string[]>([]);
  const [diets, setDiets] = useState<string[]>([]);
  const [selectedCuisine, setSelectedCuisine] = useState<string>('');
  const [selectedDiet, setSelectedDiet] = useState<string>('');
  const [ingredientSearch, setIngredientSearch] = useState('');
  const [ingredientsList, setIngredientsList] = useState<string[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchSource, setSearchSource] = useState<'local' | 'themealdb'>('local');
  
  const navigation = useNavigation<RecipesScreenNavigationProp>();
  const route = useRoute<RecipesScreenRouteProp>();
  const category = route.params?.category;

  useEffect(() => {
    loadRecipes();
    loadFilters();
  }, [category]);

  // ✅ FUNCIÓN SEGURA PARA CARGAR RECETAS
  const loadRecipes = async () => {
    try {
      setLoading(true);
      console.log('📥 Cargando recetas...', { category, searchQuery });
      
      let recipesData: Recipe[] = [];
      
      // ✅ SI HAY TÉRMINO DE BÚSQUEDA, USAR THEMEALDB
      if (searchQuery && searchQuery.trim() !== '') {
        setSearchSource('themealdb');
        console.log('🔍 Buscando en TheMealDB:', searchQuery);
        
        const mealDbRecipes = await mealDbAPI.searchRecipes(searchQuery);
        recipesData = mealDbRecipes || [];
        
        console.log(`✅ ${recipesData.length} recetas encontradas en TheMealDB`);
      } 
      // ✅ SI HAY CATEGORÍA, USAR THEMEALDB
      else if (category && category.trim() !== '') {
        setSearchSource('themealdb');
        console.log('📁 Buscando por categoría en TheMealDB:', category);
        
        const categoryRecipes = await mealDbAPI.getRecipesByCategory(category);
        recipesData = categoryRecipes || [];
        
        console.log(`✅ ${recipesData.length} recetas de categoría "${category}" encontradas`);
      }
      // ✅ SI NO HAY BÚSQUEDA NI CATEGORÍA, USAR RECETAS LOCALES
      else {
        setSearchSource('local');
        console.log('🏠 Cargando recetas locales...');
        
        try {
          const data = await recipesAPI.getAllRecipes({ 
            cuisine: selectedCuisine || undefined,
            diet: selectedDiet || undefined
          });
          recipesData = data.recipes || [];
        } catch (localError) {
          console.log('⚠️ No se pudieron cargar recetas locales, usando recetas populares');
          // Fallback a recetas populares de TheMealDB
          const popularRecipes = await mealDbAPI.getPopularRecipes();
          recipesData = popularRecipes || [];
        }
      }
      
      // ✅ FILTRAR RECETAS VÁLIDAS
      const validRecipes = recipesData.filter(recipe => 
        recipe && 
        recipe.title && 
        recipe.title !== 'undefined' && 
        typeof recipe.title === 'string'
      );
      
      setRecipes(validRecipes);
      console.log(`🎯 ${validRecipes.length} recetas válidas cargadas`);
      
    } catch (error) {
      console.error('❌ Error cargando recetas:', error);
      Alert.alert('Error', 'No se pudieron cargar las recetas. Intenta nuevamente.');
      setRecipes([]);
    } finally {
      setLoading(false);
      setSearchLoading(false);
    }
  };

  const loadFilters = async () => {
    try {
      const [cuisinesData, dietsData] = await Promise.all([
        recipesAPI.getCuisines(),
        recipesAPI.getDiets()
      ]);
      setCuisines(cuisinesData || []);
      setDiets(dietsData || []);
    } catch (error) {
      console.error('Error loading filters:', error);
      setCuisines([]);
      setDiets([]);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadRecipes();
    setRefreshing(false);
  };

  // ✅ FUNCIÓN SEGURA PARA BÚSQUEDA
  const handleSearch = async () => {
    // ✅ VERIFICAR TÉRMINO DE BÚSQUEDA
    if (!searchQuery || searchQuery.trim() === '') {
      Alert.alert('Búsqueda vacía', 'Por favor ingresa un término de búsqueda');
      return;
    }

    setIngredientsList([]);
    setSearchLoading(true);
    
    try {
      console.log('🔍 Ejecutando búsqueda:', searchQuery);
      await loadRecipes();
    } catch (error) {
      console.error('❌ Error en búsqueda:', error);
      Alert.alert('Error', 'No se pudo completar la búsqueda');
    }
  };

  const handleFilter = () => {
    setShowFilters(true);
  };

  const applyFilters = async () => {
    setShowFilters(false);
    setIngredientsList([]);
    setSearchLoading(true);
    await loadRecipes();
  };

  const clearFilters = async () => {
    setSelectedCuisine('');
    setSelectedDiet('');
    setSearchQuery('');
    setIngredientsList([]);
    setSearchSource('local');
    setSearchLoading(true);
    await loadRecipes();
  };

  const handleRecipePress = (recipe: Recipe) => {
    if (!recipe || !recipe._id) {
      console.error('❌ Receta inválida para navegar:', recipe);
      Alert.alert('Error', 'No se puede ver esta receta');
      return;
    }
    
    navigation.navigate('RecipeDetail', { recipeId: recipe._id });
  };

  const handleAddIngredient = () => {
    if (ingredientSearch.trim() && !ingredientsList.includes(ingredientSearch.trim())) {
      setIngredientsList([...ingredientsList, ingredientSearch.trim()]);
      setIngredientSearch('');
    }
  };

  const handleRemoveIngredient = (ingredient: string) => {
    setIngredientsList(ingredientsList.filter(item => item !== ingredient));
  };

  const handleSearchByIngredients = async () => {
    if (ingredientsList.length === 0) {
      Alert.alert('Sin ingredientes', 'Agrega al menos un ingrediente');
      return;
    }
    
    setSearchLoading(true);
    try {
      setSearchQuery('');
      const recipes = await recipesAPI.searchRecipesByIngredients(ingredientsList);
      setRecipes(recipes || []);
      setSearchSource('local');
    } catch (error) {
      console.error('Error buscando por ingredientes:', error);
      Alert.alert('Error', 'No se pudieron buscar recetas por ingredientes');
    } finally {
      setSearchLoading(false);
    }
  };

  // ✅ RENDER ITEM SEGURO
  const renderRecipeItem = ({ item }: { item: Recipe }) => {
    if (!item || !item.title) {
      console.log('⚠️ Receta inválida en render:', item);
      return null;
    }
    
    return (
      <RecipeCard 
        recipe={item} 
        onPress={() => handleRecipePress(item)} 
      />
    );
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={styles.loadingText}>Cargando recetas...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Barra de búsqueda y filtros */}
      <View style={styles.searchContainer}>
        {/* ✅ INDICADOR DE FUENTE */}
        <View style={styles.sourceIndicator}>
          <Text style={styles.sourceText}>
            Fuente: {searchSource === 'themealdb' ? '🌍 TheMealDB' : '🏠 Recetas Locales'}
          </Text>
        </View>

        <View style={styles.searchRow}>
          <TextInput
            style={styles.searchInput}
            placeholder="Buscar recetas..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
            editable={!searchLoading}
            placeholderTextColor="#9CA3AF"
          />
          <TouchableOpacity 
            style={styles.filterButton} 
            onPress={handleFilter}
            disabled={searchLoading}
          >
            <Text>⚙️</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.searchButton, searchLoading && styles.searchButtonDisabled]} 
            onPress={handleSearch}
            disabled={searchLoading}
          >
            <Text style={styles.searchButtonText}>{searchLoading ? '⏳' : '🔍'}</Text>
          </TouchableOpacity>
        </View>
        
        {/* Loading durante búsqueda */}
        {searchLoading && (
          <View style={styles.searchLoading}>
            <ActivityIndicator size="small" color="#3B82F6" />
            <Text style={styles.searchLoadingText}>
              {searchSource === 'themealdb' ? 'Buscando en TheMealDB...' : 'Buscando recetas...'}
            </Text>
          </View>
        )}
        
        {/* Búsqueda por ingredientes (solo para recetas locales) */}
        {searchSource === 'local' && (
          <View style={styles.ingredientsContainer}>
            <Text style={styles.ingredientsTitle}>Buscar por ingredientes:</Text>
            <View style={styles.ingredientsInputRow}>
              <TextInput
                style={styles.ingredientsInput}
                placeholder="Ej: tomate, cebolla, pollo..."
                value={ingredientSearch}
                onChangeText={setIngredientSearch}
                onSubmitEditing={handleAddIngredient}
                editable={!searchLoading}
                placeholderTextColor="#9CA3AF"
              />
              <TouchableOpacity 
                style={[styles.addButton, searchLoading && styles.addButtonDisabled]} 
                onPress={handleAddIngredient}
                disabled={searchLoading}
              >
                <Text style={styles.addButtonText}>+</Text>
              </TouchableOpacity>
            </View>
            
            {ingredientsList.length > 0 && (
              <View style={styles.ingredientsTags}>
                <Text style={styles.ingredientsLabel}>Ingredientes:</Text>
                <View style={styles.tagsContainer}>
                  {ingredientsList.map((ingredient, index) => (
                    <TouchableOpacity 
                      key={index} 
                      style={styles.tag}
                      onPress={() => !searchLoading && handleRemoveIngredient(ingredient)}
                      disabled={searchLoading}
                    >
                      <Text style={styles.tagText}>{ingredient} ×</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                <TouchableOpacity 
                  style={[styles.searchByIngredientsButton, searchLoading && styles.searchByIngredientsButtonDisabled]} 
                  onPress={handleSearchByIngredients}
                  disabled={searchLoading}
                >
                  <Text style={styles.searchByIngredientsText}>
                    {searchLoading ? 'Buscando...' : 'Buscar Recetas'}
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}

        {/* Información de filtros activos */}
        {(category || selectedCuisine || selectedDiet || ingredientsList.length > 0 || searchQuery) && (
          <View style={styles.filtersInfo}>
            <Text style={styles.filtersText} numberOfLines={2}>
              {category && `Categoría: ${category} `}
              {selectedCuisine && `Cocina: ${selectedCuisine} `}
              {selectedDiet && `Dieta: ${selectedDiet} `}
              {searchQuery && `Búsqueda: "${searchQuery}" `}
              {ingredientsList.length > 0 && `Ingredientes: ${ingredientsList.join(', ')}`}
            </Text>
            <TouchableOpacity onPress={clearFilters} disabled={searchLoading}>
              <Text style={[styles.clearText, searchLoading && styles.clearTextDisabled]}>
                Limpiar
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Lista de recetas */}
      <FlatList
        data={recipes}
        renderItem={renderRecipeItem}
        keyExtractor={(item) => item._id || `recipe-${Date.now()}-${Math.random()}`}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              {searchLoading 
                ? 'Buscando recetas...' 
                : searchQuery 
                  ? `No se encontraron recetas para "${searchQuery}"`
                  : 'No se encontraron recetas'
              }
            </Text>
            {!searchLoading && (
              <TouchableOpacity style={styles.retryButton} onPress={loadRecipes}>
                <Text style={styles.retryText}>Reintentar</Text>
              </TouchableOpacity>
            )}
          </View>
        }
      />

      {/* Modal de Filtros (solo para recetas locales) */}
      <Modal
        visible={showFilters}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Filtros de Búsqueda</Text>
            
            <ScrollView>
              {/* Filtro de Cocina */}
              <View style={styles.filterSection}>
                <Text style={styles.filterLabel}>Cocina</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {cuisines.map((cuisine) => (
                    <TouchableOpacity
                      key={cuisine}
                      style={[
                        styles.filterChip,
                        selectedCuisine === cuisine && styles.filterChipSelected
                      ]}
                      onPress={() => setSelectedCuisine(
                        selectedCuisine === cuisine ? '' : cuisine
                      )}
                    >
                      <Text style={[
                        styles.filterChipText,
                        selectedCuisine === cuisine && styles.filterChipTextSelected
                      ]}>
                        {cuisine}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>

              {/* Filtro de Dieta */}
              <View style={styles.filterSection}>
                <Text style={styles.filterLabel}>Dieta</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {diets.map((diet) => (
                    <TouchableOpacity
                      key={diet}
                      style={[
                        styles.filterChip,
                        selectedDiet === diet && styles.filterChipSelected
                      ]}
                      onPress={() => setSelectedDiet(
                        selectedDiet === diet ? '' : diet
                      )}
                    >
                      <Text style={[
                        styles.filterChipText,
                        selectedDiet === diet && styles.filterChipTextSelected
                      ]}>
                        {diet}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
            </ScrollView>

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setShowFilters(false)}>
                <Text style={styles.cancelButtonText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.applyButton} onPress={applyFilters}>
                <Text style={styles.applyButtonText}>Aplicar Filtros</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  searchContainer: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  sourceIndicator: {
    backgroundColor: '#EFF6FF',
    padding: 8,
    borderRadius: 6,
    marginBottom: 8,
    alignItems: 'center',
  },
  sourceText: {
    fontSize: 12,
    color: '#3B82F6',
    fontWeight: '500',
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchInput: {
    flex: 1,
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#D1D5DB',
  },
  searchButton: {
    padding: 12,
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    marginLeft: 4,
    minWidth: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchButtonDisabled: {
    backgroundColor: '#9CA3AF',
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  filterButton: {
    padding: 12,
    backgroundColor: '#6B7280',
    borderRadius: 8,
    marginLeft: 4,
    minWidth: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
    padding: 8,
    backgroundColor: '#EFF6FF',
    borderRadius: 8,
  },
  searchLoadingText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#3B82F6',
    fontWeight: '500',
  },
  ingredientsContainer: {
    marginTop: 12,
    padding: 12,
    backgroundColor: '#F8F9FA',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  ingredientsTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    color: '#374151',
  },
  ingredientsInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ingredientsInput: {
    flex: 1,
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 6,
    fontSize: 14,
    borderWidth: 1,
    borderColor: '#D1D5DB',
  },
  addButton: {
    padding: 10,
    backgroundColor: '#10B981',
    borderRadius: 6,
    marginLeft: 8,
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButtonDisabled: {
    backgroundColor: '#9CA3AF',
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  ingredientsTags: {
    marginTop: 12,
  },
  ingredientsLabel: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 6,
    color: '#374151',
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 8,
  },
  tag: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  tagText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  searchByIngredientsButton: {
    backgroundColor: '#8B5CF6',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  searchByIngredientsButtonDisabled: {
    backgroundColor: '#9CA3AF',
  },
  searchByIngredientsText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 14,
  },
  filtersInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    padding: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 6,
  },
  filtersText: {
    fontSize: 12,
    color: '#6B7280',
    flex: 1,
  },
  clearText: {
    fontSize: 12,
    color: '#EF4444',
    fontWeight: '500',
  },
  clearTextDisabled: {
    color: '#9CA3AF',
  },
  listContent: {
    padding: 16,
    flexGrow: 1,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#6B7280',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: '#3B82F6',
    borderRadius: 8,
  },
  retryText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 14,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#1F2937',
  },
  filterSection: {
    marginBottom: 20,
  },
  filterLabel: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 10,
    color: '#374151',
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#D1D5DB',
  },
  filterChipSelected: {
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
  },
  filterChipText: {
    color: '#374151',
    fontSize: 14,
    fontWeight: '500',
  },
  filterChipTextSelected: {
    color: 'white',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  cancelButton: {
    flex: 1,
    padding: 16,
    backgroundColor: '#6B7280',
    borderRadius: 8,
    marginRight: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 16,
  },
  applyButton: {
    flex: 1,
    padding: 16,
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    marginLeft: 8,
    alignItems: 'center',
  },
  applyButtonText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 16,
  },
});

export default RecipesScreen;