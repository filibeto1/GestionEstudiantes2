import React, { useState, useEffect } from 'react';
import { 
  ScrollView, 
  StyleSheet, 
  Text, 
  View, 
  Switch, 
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { UserProfileData } from '../types';

const ALLERGIES = [
  'Gluten', 'Lactosa', 'Mariscos', 'Frutos secos', 'Huevos', 
  'Soja', 'Pescado', 'Apio', 'Mostaza', 'Sésamo'
];

const DIETARY_RESTRICTIONS = [
  'Vegetariano', 'Vegano', 'Sin gluten', 'Sin lactosa', 
  'Bajo en sodio', 'Bajo en carbohidratos', 'Keto', 'Paleo'
];

const HEALTH_CONDITIONS = [
  'Diabetes', 'Hipertensión', 'Colesterol alto', 'Enfermedad celíaca',
  'Intolerancia a la lactosa', 'Alergias alimentarias', 'Sobrepeso'
];

const HEALTH_GOALS = [
  'Perder peso', 'Ganar masa muscular', 'Mantener peso', 
  'Mejorar digestión', 'Controlar diabetes', 'Reducir colesterol'
];

const ACTIVITY_LEVELS: { label: string; value: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active' }[] = [
  { label: 'Sedentario', value: 'sedentary' },
  { label: 'Ligero', value: 'light' },
  { label: 'Moderado', value: 'moderate' },
  { label: 'Activo', value: 'active' },
  { label: 'Muy activo', value: 'very_active' }
];

const GENDER_OPTIONS: { label: string; value: 'male' | 'female' | 'other' | 'prefer_not_to_say' }[] = [
  { label: 'Masculino', value: 'male' },
  { label: 'Femenino', value: 'female' },
  { label: 'Otro', value: 'other' },
  { label: 'Prefiero no decir', value: 'prefer_not_to_say' }
];

// Define interface para healthInfo
interface HealthInfo {
  allergies: string[];
  dietaryRestrictions: string[];
  healthConditions: string[];
  healthGoals: string[];
}

export const ProfileScreen: React.FC = () => {
  const { user, userProfile, logout, updatePersonalInfo, updateHealthInfo, refreshUserProfile } = useAuth();
  
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [tempValue, setTempValue] = useState<string>('');

  // Cargar perfil cuando el componente se monte
  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      setLoading(true);
      console.log('🔄 Cargando perfil...');
      
      await refreshUserProfile();
      console.log('✅ Perfil cargado exitosamente');
      
    } catch (error) {
      console.error('❌ Error cargando perfil:', error);
      Alert.alert('Error', 'No se pudo cargar la información del perfil');
    } finally {
      setLoading(false);
    }
  };

  const savePersonalInfo = async (newPersonalInfo: UserProfileData['personalInfo']) => {
    try {
      setSaving(true);
      await updatePersonalInfo(newPersonalInfo);
      console.log('✅ Información personal guardada exitosamente');
    } catch (error) {
      console.error('Error guardando información personal:', error);
      Alert.alert('Error', 'No se pudo guardar la información personal');
    } finally {
      setSaving(false);
    }
  };

  const saveHealthInfo = async (newHealthInfo: UserProfileData['healthInfo']) => {
    try {
      setSaving(true);
      await updateHealthInfo(newHealthInfo);
      console.log('✅ Información de salud guardada exitosamente');
    } catch (error) {
      console.error('Error guardando información de salud:', error);
      Alert.alert('Error', 'No se pudo guardar la información de salud');
    } finally {
      setSaving(false);
    }
  };

  // ✅ CORREGIDO: Tipo explícito para el parámetro category
  const toggleSelection = (category: keyof HealthInfo, value: string) => {
    if (!userProfile || !userProfile.healthInfo) return;
    
    const currentItems = userProfile.healthInfo[category] || [];
    const newItems = currentItems.includes(value)
      ? currentItems.filter((item: string) => item !== value)
      : [...currentItems, value];
    
    const newHealthInfo = {
      ...userProfile.healthInfo,
      [category]: newItems
    };
    
    saveHealthInfo(newHealthInfo);
  };

  const openEditModal = (field: string, currentValue: any) => {
    setEditingField(field);
    setTempValue(currentValue?.toString() || '');
    setEditModalVisible(true);
  };

  const saveField = () => {
    if (!editingField || !userProfile) return;

    let newValue: any = tempValue;

    // Convertir a número si es edad, peso o altura
    if (['age', 'weight', 'height', 'dailyCalorieGoal'].includes(editingField)) {
      newValue = tempValue ? parseInt(tempValue) : undefined;
    }

    const newPersonalInfo = {
      ...userProfile.personalInfo,
      [editingField]: newValue
    };
    
    savePersonalInfo(newPersonalInfo);
    setEditModalVisible(false);
    setEditingField(null);
    setTempValue('');
  };

  const handleGenderSelection = (gender: 'male' | 'female' | 'other' | 'prefer_not_to_say') => {
    if (!userProfile) return;
    
    const newPersonalInfo = {
      ...userProfile.personalInfo,
      gender
    };
    savePersonalInfo(newPersonalInfo);
  };

  const handleActivityLevelSelection = (activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active') => {
    if (!userProfile) return;
    
    const newPersonalInfo = {
      ...userProfile.personalInfo,
      activityLevel
    };
    savePersonalInfo(newPersonalInfo);
  };

  const handleLogout = async () => {
    Alert.alert(
      'Cerrar Sesión',
      '¿Estás seguro de que quieres cerrar sesión?',
      [
        { 
          text: 'Cancelar', 
          style: 'cancel' 
        },
        { 
          text: 'Cerrar Sesión', 
          onPress: async () => {
            try {
              await logout();
              console.log('✅ Sesión cerrada exitosamente');
            } catch (error) {
              console.error('❌ Error al cerrar sesión:', error);
              Alert.alert('Error', 'No se pudo cerrar sesión');
            }
          }, 
          style: 'destructive' 
        }
      ]
    );
  };

  const calculateBMI = (): string => {
    if (!userProfile?.personalInfo?.weight || !userProfile?.personalInfo?.height) return 'No disponible';
    
    const heightInMeters = userProfile.personalInfo.height / 100;
    const bmi = userProfile.personalInfo.weight / (heightInMeters * heightInMeters);
    return bmi.toFixed(1);
  };

  const getBMICategory = (bmi: string): string => {
    const bmiValue = parseFloat(bmi);
    if (isNaN(bmiValue)) return '';
    if (bmiValue < 18.5) return 'Bajo peso';
    if (bmiValue < 25) return 'Peso normal';
    if (bmiValue < 30) return 'Sobrepeso';
    return 'Obesidad';
  };

  const getGenderLabel = (gender?: string): string => {
    const option = GENDER_OPTIONS.find(opt => opt.value === gender);
    return option?.label || 'No especificado';
  };

  const getActivityLevelLabel = (level?: string): string => {
    const option = ACTIVITY_LEVELS.find(opt => opt.value === level);
    return option?.label || 'No especificado';
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={styles.loadingText}>Cargando perfil...</Text>
      </View>
    );
  }

  // Si no hay perfil, mostrar estado vacío
  if (!userProfile) {
    return (
      <View style={styles.centered}>
        <Text style={styles.loadingText}>No se pudo cargar el perfil</Text>
        <TouchableOpacity style={styles.retryButton} onPress={loadProfile}>
          <Text style={styles.retryButtonText}>Reintentar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView style={styles.scrollView}>
        {/* Header con información del usuario */}
        <View style={styles.header}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user?.username?.charAt(0).toUpperCase() || 'U'}
            </Text>
          </View>
          <Text style={styles.userName}>{user?.username}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
          
          {saving && (
            <View style={styles.savingIndicator}>
              <ActivityIndicator size="small" color="#FFFFFF" />
              <Text style={styles.savingText}>Guardando...</Text>
            </View>
          )}
        </View>

        {/* Información Básica de Salud */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Información Básica</Text>
          <Text style={styles.sectionSubtitle}>
            Toca en cada campo para editar tu información
          </Text>
          
          <View style={styles.basicInfo}>
            {/* Edad */}
            <TouchableOpacity 
              style={styles.infoItem}
              onPress={() => openEditModal('age', userProfile.personalInfo?.age)}
            >
              <Text style={styles.infoLabel}>Edad</Text>
              <Text style={styles.infoValue}>
                {userProfile.personalInfo?.age ? `${userProfile.personalInfo.age} años` : 'Toca para agregar'}
              </Text>
            </TouchableOpacity>

            {/* Peso */}
            <TouchableOpacity 
              style={styles.infoItem}
              onPress={() => openEditModal('weight', userProfile.personalInfo?.weight)}
            >
              <Text style={styles.infoLabel}>Peso</Text>
              <Text style={styles.infoValue}>
                {userProfile.personalInfo?.weight ? `${userProfile.personalInfo.weight} kg` : 'Toca para agregar'}
              </Text>
            </TouchableOpacity>

            {/* Altura */}
            <TouchableOpacity 
              style={styles.infoItem}
              onPress={() => openEditModal('height', userProfile.personalInfo?.height)}
            >
              <Text style={styles.infoLabel}>Altura</Text>
              <Text style={styles.infoValue}>
                {userProfile.personalInfo?.height ? `${userProfile.personalInfo.height} cm` : 'Toca para agregar'}
              </Text>
            </TouchableOpacity>

            {/* Género */}
            <TouchableOpacity 
              style={styles.infoItem}
              onPress={() => {
                Alert.alert(
                  'Seleccionar Género',
                  'Elige tu género:',
                  [
                    ...GENDER_OPTIONS.map(option => ({
                      text: option.label,
                      onPress: () => handleGenderSelection(option.value)
                    })),
                    { text: 'Cancelar', style: 'cancel' }
                  ]
                );
              }}
            >
              <Text style={styles.infoLabel}>Género</Text>
              <Text style={styles.infoValue}>
                {getGenderLabel(userProfile.personalInfo?.gender)}
              </Text>
            </TouchableOpacity>

            {/* IMC */}
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>IMC</Text>
              <Text style={styles.infoValue}>
                {calculateBMI()}
              </Text>
              {userProfile.personalInfo?.weight && userProfile.personalInfo?.height && (
                <Text style={styles.bmiCategory}>
                  {getBMICategory(calculateBMI())}
                </Text>
              )}
            </View>

            {/* Nivel de Actividad */}
            <TouchableOpacity 
              style={styles.infoItem}
              onPress={() => {
                Alert.alert(
                  'Nivel de Actividad',
                  'Selecciona tu nivel de actividad física:',
                  [
                    ...ACTIVITY_LEVELS.map(option => ({
                      text: option.label,
                      onPress: () => handleActivityLevelSelection(option.value)
                    })),
                    { text: 'Cancelar', style: 'cancel' }
                  ]
                );
              }}
            >
              <Text style={styles.infoLabel}>Actividad</Text>
              <Text style={styles.infoValue}>
                {getActivityLevelLabel(userProfile.personalInfo?.activityLevel)}
              </Text>
            </TouchableOpacity>

            {/* Meta Calórica Diaria */}
            <TouchableOpacity 
              style={styles.infoItem}
              onPress={() => openEditModal('dailyCalorieGoal', userProfile.personalInfo?.dailyCalorieGoal)}
            >
              <Text style={styles.infoLabel}>Calorías/día</Text>
              <Text style={styles.infoValue}>
                {userProfile.personalInfo?.dailyCalorieGoal ? `${userProfile.personalInfo.dailyCalorieGoal} kcal` : 'Toca para agregar'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Información de Salud Detallada */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🍎 Información de Salud</Text>
          <Text style={styles.sectionSubtitle}>
            Esta información nos ayuda a recomendarte recetas adecuadas para ti
          </Text>

          {/* Alergias */}
          <View style={styles.category}>
            <Text style={styles.categoryTitle}>Alergias Alimentarias</Text>
            {ALLERGIES.map(allergy => (
              <TouchableOpacity
                key={allergy}
                style={styles.optionRow}
                onPress={() => toggleSelection('allergies', allergy)}
              >
                <Text style={styles.optionText}>{allergy}</Text>
                <Switch
                  value={userProfile.healthInfo?.allergies?.includes(allergy) || false}
                  onValueChange={() => toggleSelection('allergies', allergy)}
                  trackColor={{ false: '#D1D5DB', true: '#3B82F6' }}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* Restricciones Dietéticas */}
          <View style={styles.category}>
            <Text style={styles.categoryTitle}>Restricciones Dietéticas</Text>
            {DIETARY_RESTRICTIONS.map(restriction => (
              <TouchableOpacity
                key={restriction}
                style={styles.optionRow}
                onPress={() => toggleSelection('dietaryRestrictions', restriction)}
              >
                <Text style={styles.optionText}>{restriction}</Text>
                <Switch
                  value={userProfile.healthInfo?.dietaryRestrictions?.includes(restriction) || false}
                  onValueChange={() => toggleSelection('dietaryRestrictions', restriction)}
                  trackColor={{ false: '#D1D5DB', true: '#10B981' }}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* Condiciones de Salud */}
          <View style={styles.category}>
            <Text style={styles.categoryTitle}>Condiciones de Salud</Text>
            {HEALTH_CONDITIONS.map(condition => (
              <TouchableOpacity
                key={condition}
                style={styles.optionRow}
                onPress={() => toggleSelection('healthConditions', condition)}
              >
                <Text style={styles.optionText}>{condition}</Text>
                <Switch
                  value={userProfile.healthInfo?.healthConditions?.includes(condition) || false}
                  onValueChange={() => toggleSelection('healthConditions', condition)}
                  trackColor={{ false: '#D1D5DB', true: '#EF4444' }}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* Objetivos de Salud */}
          <View style={styles.category}>
            <Text style={styles.categoryTitle}>Objetivos de Salud</Text>
            {HEALTH_GOALS.map(goal => (
              <TouchableOpacity
                key={goal}
                style={styles.optionRow}
                onPress={() => toggleSelection('healthGoals', goal)}
              >
                <Text style={styles.optionText}>{goal}</Text>
                <Switch
                  value={userProfile.healthInfo?.healthGoals?.includes(goal) || false}
                  onValueChange={() => toggleSelection('healthGoals', goal)}
                  trackColor={{ false: '#D1D5DB', true: '#8B5CF6' }}
                />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Resumen */}
        <View style={styles.summary}>
          <Text style={styles.summaryTitle}>Resumen de tu Perfil de Salud</Text>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Alergias:</Text>
            <Text style={styles.summaryValue}>
              {userProfile.healthInfo?.allergies && userProfile.healthInfo.allergies.length > 0 
                ? userProfile.healthInfo.allergies.join(', ') 
                : 'Ninguna'}
            </Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Dieta:</Text>
            <Text style={styles.summaryValue}>
              {userProfile.healthInfo?.dietaryRestrictions && userProfile.healthInfo.dietaryRestrictions.length > 0 
                ? userProfile.healthInfo.dietaryRestrictions.join(', ') 
                : 'Sin restricciones'}
            </Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Condiciones:</Text>
            <Text style={styles.summaryValue}>
              {userProfile.healthInfo?.healthConditions && userProfile.healthInfo.healthConditions.length > 0 
                ? userProfile.healthInfo.healthConditions.join(', ') 
                : 'Ninguna'}
            </Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Objetivos:</Text>
            <Text style={styles.summaryValue}>
              {userProfile.healthInfo?.healthGoals && userProfile.healthInfo.healthGoals.length > 0 
                ? userProfile.healthInfo.healthGoals.join(', ') 
                : 'No especificados'}
            </Text>
          </View>
        </View>

        {/* Cerrar Sesión */}
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutText}>Cerrar Sesión</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Modal para editar campos */}
      <Modal
        visible={editModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setEditModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              Editar {editingField === 'age' ? 'Edad' : 
                     editingField === 'weight' ? 'Peso' : 
                     editingField === 'height' ? 'Altura' : 
                     editingField === 'dailyCalorieGoal' ? 'Meta Calórica' : 'Campo'}
            </Text>
            
            <TextInput
              style={styles.textInput}
              value={tempValue}
              onChangeText={setTempValue}
              placeholder={
                editingField === 'age' ? 'Ingresa tu edad (años)' :
                editingField === 'weight' ? 'Ingresa tu peso (kg)' :
                editingField === 'height' ? 'Ingresa tu altura (cm)' :
                editingField === 'dailyCalorieGoal' ? 'Ingresa calorías diarias' :
                'Ingresa el valor'
              }
              keyboardType="numeric"
              autoFocus={true}
            />
            
            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setEditModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>Cancelar</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.modalButton, styles.saveButton]}
                onPress={saveField}
              >
                <Text style={styles.saveButtonText}>Guardar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
  },
  header: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#3B82F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 16,
    color: '#6B7280',
  },
  savingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3B82F6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginTop: 8,
  },
  savingText: {
    color: '#FFFFFF',
    fontSize: 12,
    marginLeft: 6,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 16,
    lineHeight: 20,
  },
  basicInfo: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  infoItem: {
    width: '48%',
    padding: 12,
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    marginBottom: 8,
  },
  infoLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1F2937',
  },
  bmiCategory: {
    fontSize: 12,
    color: '#6B7280',
    fontStyle: 'italic',
    marginTop: 2,
  },
  category: {
    marginBottom: 24,
  },
  categoryTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
  },
  optionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  optionText: {
    fontSize: 16,
    color: '#374151',
    flex: 1,
  },
  summary: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 12,
  },
  summaryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  summaryLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
  },
  summaryValue: {
    fontSize: 14,
    color: '#6B7280',
    flex: 1,
    textAlign: 'right',
  },
  logoutButton: {
    backgroundColor: '#EF4444',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  logoutText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    width: '80%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: '#1F2937',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 20,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: '#F3F4F6',
  },
  saveButton: {
    backgroundColor: '#3B82F6',
  },
  cancelButtonText: {
    color: '#374151',
    fontWeight: '600',
  },
  saveButtonText: {
    color: 'white',
    fontWeight: '600',
  },
  retryButton: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 10,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
});