// src/types/index.ts - ACTUALIZAR
export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user' | 'moderator'; // ← AGREGAR 'moderator'
  isActive: boolean; // ← AGREGAR isActive
  profile?: UserProfileData;
}

export interface UserProfileData {
  personalInfo?: {
    age?: number;
    weight?: number;
    height?: number;
    gender?: string;
    avatar?: string;
  };
  healthInfo: {
    allergies: string[];
    dietaryRestrictions: string[];
    healthConditions: string[];
    healthGoals: string[];
  };
  preferences: {
    favoriteCuisines: string[];
    dislikedIngredients: string[];
    cookingSkills: 'beginner' | 'intermediate' | 'advanced';
  };
}

// ✅ INTERFACES CORREGIDAS - SIN DUPLICADOS
export interface Ingredient {
  name: string;
  quantity: string;
  unit: string;
}

export interface Instruction {
  step: number;
  description: string;
}

export interface Rating {
  user: string;
  rating: number;
}

export interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface RecipeSearchFilters {
  cuisine?: string;
  diet?: string;
  intolerances?: string;
  maxReadyTime?: number;
}

// ✅ SOLO UNA INTERFACE RECIPE
export interface Recipe {
  _id?: string;
  title: string;
  description: string;
  ingredients: Ingredient[];
  instructions: Instruction[];
  preparationTime: number;
  servings: number;
  difficulty: 'Fácil' | 'Medio' | 'Difícil';
  category: 'Desayuno' | 'Almuerzo' | 'Cena' | 'Postre' | 'Snack' | 'Bebida';
  image?: string;
  author: string;
  authorName: string;
  likes: string[];
  likesCount: number;
  ratings?: Rating[];
  nutritionInfo?: NutritionInfo;
  createdAt?: string;
  updatedAt?: string;
}

export interface AuthResponse {
  message: string;
  token: string;
  user: User;
}

export interface RecipesResponse {
  recipes: Recipe[];
  totalPages: number;
  currentPage: number;
  total: number;
}

// ✅ TIPOS PARA NAVEGACIÓN ACTUALIZADOS
export type RootStackParamList = {
  // Auth Screens
  Login: undefined;
  Register: undefined;
  
  // Main Tabs
  Main: undefined;
  Home: undefined;
  Recipes: { category?: string } | undefined;
  Profile: undefined;
  Admin: undefined; // ✅ AÑADIDA PANTALLA ADMIN
  
  // Recipe Screens
  RecipeDetail: { recipeId: string };
  CreateRecipe: undefined;
  CommunityRecipes: undefined;
  MyRecipes: undefined;
};