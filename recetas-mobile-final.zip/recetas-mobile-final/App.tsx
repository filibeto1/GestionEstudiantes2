// App.tsx - AGREGAR LA NUEVA PANTALLA
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { PermissionsProvider } from './src/hooks/usePermissions';
import { CreateAdminScreen } from './src/screens/CreateAdminScreen';
import { AdminScreen } from './src/screens/AdminScreen';
// ... otras importaciones

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <PermissionsProvider>
      <NavigationContainer>
        <Stack.Navigator>
          {/* Agregar esta ruta para desarrollo */}
          <Stack.Screen 
            name="CreateAdmin" 
            component={CreateAdminScreen}
            options={{ title: 'Crear Admin (Dev)' }}
          />
          <Stack.Screen 
            name="Admin" 
            component={AdminScreen}
            options={{ title: 'Panel de Administración' }}
          />
          {/* ... otras rutas */}
        </Stack.Navigator>
      </NavigationContainer>
    </PermissionsProvider>
  );
}